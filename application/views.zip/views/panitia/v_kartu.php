<!--Counter Inbox-->
<?php
    $query=$this->db->query("SELECT * FROM tbl_inbox WHERE inbox_status='1'");
    $query2=$this->db->query("SELECT * FROM tbl_komentar WHERE komentar_status='0'");
    $jum_comment=$query2->num_rows();
    $jum_pesan=$query->num_rows();
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SAPA-SKO | Data Peserta</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="shorcut icon" type="text/css" href="<?php echo base_url().'theme/images/logo-dark.png'?>">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/bootstrap/css/bootstrap.min.css'?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/font-awesome/css/font-awesome.min.css'?>">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/plugins/datatables/dataTables.bootstrap.css'?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/dist/css/AdminLTE.min.css'?>">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/dist/css/skins/_all-skins.min.css'?>">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/plugins/toast/jquery.toast.min.css'?>"/>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

   <?php
    $this->load->view('peserta/v_header');
  ?>
  <!-- Left side column. contains the logo and sidebar -->
  <?php
    $this->load->view('peserta/v_samping');
  ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Peserta
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Pengguna</a></li>
        <li class="active">Data Peserta Atlet</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">

          <div class="box">
            
            <!-- /.box-header -->
            <div class="box-body">
              <table border="1" cellpadding="20">
                
                <tbody>
				<?php 
				
			//	$hasil= $dataPerusahaan->row();

//echo $hasil->nama_perusahaan;
			$hasil          = $data->row();
			$cek_peserta    = $peserta->row();
			$cek_galeri     = $galeri->row();
			$cek_link       = $link->row();
			$cek_prestasi   = $prestasi->row();
			
			$valid_peserta    = $peserta1->row();
			$valid_galeri     = $galeri1->row();
			$valid_link       = $link1->row();
			$valid_prestasi   = $prestasi1->row();
			
			
                     /*  $pengguna_id=$i['id_peserta'];
                       $pengguna_nama=$i['nama_peserta'];
                       $pengguna_email=$i['email_peserta'];
                       $pengguna_username=$i['nisn'];
                       $pengguna_nohp=$i['hp'];
                       $pengguna_photo=$i['foto_peserta'];
                      
                    */
                    $id_peserta=$hasil->id_peserta;
                    $foto_peserta=$hasil->foto_peserta;
                    $nisn=$hasil->nisn;
                    $nama_peserta=$hasil->nama_peserta;
                    $email_peserta=$hasil->email_peserta;
                    $jns_kelamin=$hasil->jns_kelamin;
                    $tmpt_lahir=$hasil->tmpt_lahir;
                    $tgl_lahir=$hasil->tgl_lahir;
                    $tinggi_badan=$hasil->tinggi_badan;
                    $berat_badan=$hasil->berat_badan;
                    $gol_darah=$hasil->gol_darah;
                    $agama=$hasil->agama;
                    $alamat_rumah=$hasil->alamat_rumah;
                    $hp=$hasil->hp;
                    $nama_bapak=$hasil->nama_bapak;
                    $tinggi_bapak=$hasil->tinggi_bapak;
                    $nama_ibu=$hasil->nama_ibu;
                    $tinggi_ibu=$hasil->tinggi_ibu;
                    $jml_saudara=$hasil->jml_saudara;
                    $hobby=$hasil->hobby;
                    $cabor=$hasil->nm_cabor;
                    $posisi=$hasil->nm_posisi;
                    $barcode=$hasil->barcode;
                    //cek peserta
                    
                    $peserta=$cek_peserta->cek_peserta;
                    $galeri=$cek_galeri->cek_galeri;
                    $link=$cek_link->cek_link;
                    $prestasi=$cek_prestasi->cek_prestasi;
                    
                    $peserta1=$valid_peserta->valid_peserta;
                    $galeri1=$valid_galeri->valid_galeri;
                    $link1=$valid_link->valid_link;
                    $prestasi1=$valid_prestasi->valid_prestasi;
                    ?>
                    
                <tr>
                  <td><img width="150" height="150"  src="<?php echo base_url().'assets/images/'.$barcode;?>"?></td>
                  <td></td>
                  <td><center><img width="150" height="150"  src="<?php echo base_url().'assets/images/'.$foto_peserta?>"?></center>
                  </td>
                </tr>
                <tr>
                 </tr>
                <tr>
                  <td>Nama Cabor</td>
                  <td> : </td>
                  <td><?php echo $cabor;?></td>
                </tr>
                <tr>
                  <td>Nama Posisi </td>
                  <td> : </td>
                  <td><?php echo $posisi;?></td>
                </tr>
                <tr>
                  <td>NISN </td>
                  <td> : </td>
                  <td><?php echo $nisn;?></td>
                </tr>
                <tr>
                  <td>Nama Lengkap </td>
                  <td> : </td>
                  <td><?php echo $nama_peserta;?></td>
                </tr>
                 
               
                <tr>
                  <td> </td>
                  <td> </td>
                  <td>
                      <?php
                      if($peserta1==0 && $galeri1==0 && $link1==0 && $prestasi1==0 && $peserta==0 && $galeri==0 && $link==0 && $prestasi==0)
                      {
                          ?>
                          <a href="https://sapasko.id/peserta/cetak">Cetak Kartu Tes</a>
                          <?php 
                      }else                       {
                          echo "TIDAK MENCETAK KARTU PESERTA <BR>
                          KARENA DATA SEPERTI DIBAWAH INI";
                      }
                      
                      
                      
                      ?>
                      <br>
                      ----------------------------------------------------------
                      <BR>
                      RESUME DATA
                      <br>
                      
                    1. Data Peserta Belum diCek Panitia  : <?php echo $peserta1; ?> <br>
                       2. Data Link Belum diCek Panitia : <?php echo $link1; ?> <br>
                       3. Data Prestasi Belum diCek Panitia  <?php echo $prestasi1; ?><br>  
                       4. Data Upload Belum diCek Panitia  <?php echo $galeri1; ?> <br>
                       <br>
                       1. Data Peserta  Tidak Valid  : <?php echo $peserta; ?><br> 
                       2. Data Link Tidak Valid : <?php echo $link; ?> <br>
                       3. Data Prestasi Tidak Valid  <?php echo $prestasi; ?><br>  
                       4. Data Upload Tidak valid  <?php echo $galeri; ?> <br>
                  </td>
                </tr>
				<?php //endforeach;?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2019 <a href="">M1</a>.</strong> All rights reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">Recent Activity</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-birthday-cake bg-red"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>

                <p>Will be 23 on April 24th</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-user bg-yellow"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Frodo Updated His Profile</h4>

                <p>New phone +1(800)555-1234</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Nora Joined Mailing List</h4>

                <p>nora@example.com</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-file-code-o bg-green"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4>

                <p>Execution time 5 seconds</p>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

        <h3 class="control-sidebar-heading">Tasks Progress</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Custom Template Design
                <span class="label label-danger pull-right">70%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Update Resume
                <span class="label label-success pull-right">95%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-success" style="width: 95%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Laravel Integration
                <span class="label label-warning pull-right">50%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-warning" style="width: 50%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Back End Framework
                <span class="label label-primary pull-right">68%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-primary" style="width: 68%"></div>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

      </div>
      <!-- /.tab-pane -->
      <!-- Stats tab content -->
      <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
      <!-- /.tab-pane -->
      <!-- Settings tab content -->
      <div class="tab-pane" id="control-sidebar-settings-tab">
        <form method="post">
          <h3 class="control-sidebar-heading">General Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Report panel usage
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Some information about this general settings option
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Allow mail redirect
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Other sets of options are available
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Expose author name in posts
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Allow the user to show his name in blog posts
            </p>
          </div>
          <!-- /.form-group -->

          <h3 class="control-sidebar-heading">Chat Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Show me as online
              <input type="checkbox" class="pull-right" checked>
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Turn off notifications
              <input type="checkbox" class="pull-right">
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Delete chat history
              <a href="javascript:void(0)" class="text-red pull-right"><i class="fa fa-trash-o"></i></a>
            </label>
          </div>
          <!-- /.form-group -->
        </form>
      </div>
      <!-- /.tab-pane -->
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!--Modal Add Pengguna-->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Add Pengguna</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/pengguna/simpan_pengguna'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">

                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Nama</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama" class="form-control" id="inputUserName" placeholder="Nama Lengkap" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-4 control-label">Email</label>
                                        <div class="col-sm-7">
                                            <input type="email" name="xemail" class="form-control" id="inputEmail3" placeholder="Email" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Jenis Kelamin</label>
                                        <div class="col-sm-7">
                                           <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio1" value="L" name="xjenkel" checked>
                                                <label for="inlineRadio1"> Laki-Laki </label>
                                            </div>
                                            <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio1" value="P" name="xjenkel">
                                                <label for="inlineRadio2"> Perempuan </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Username</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xusername" class="form-control" id="inputUserName" placeholder="Username" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-4 control-label">Password</label>
                                        <div class="col-sm-7">
                                            <input type="password" name="xpassword" class="form-control" id="inputPassword3" placeholder="Password" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword4" class="col-sm-4 control-label">Ulangi Password</label>
                                        <div class="col-sm-7">
                                            <input type="password" name="xpassword2" class="form-control" id="inputPassword4" placeholder="Ulangi Password" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Kontak Person</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xkontak" class="form-control" id="inputUserName" placeholder="Kontak Person" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Level</label>
                                        <div class="col-sm-7">
                                            <select class="form-control" name="xlevel" required>
                                                <option value="1">Administrator</option>
                                                <option value="2">Author</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Photo</label>
                                        <div class="col-sm-7">
                                            <input type="file" name="filefoto" required/>
                                        </div>
                                    </div>


                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Simpan</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>


		<?php foreach ($data->result_array() as $i) :
		            $id_peserta=$i['id_peserta'];
                    $foto_peserta=$i['foto_peserta'];
                    $nisn=$i['nisn'];
                    $nama_peserta=$i['nama_peserta'];
                    $email_peserta=$i['email_peserta'];
                    $jns_kelamin=$i['jns_kelamin'];
                    $tmpt_lahir=$i['tmpt_lahir'];
                    $tgl_lahir=$i['tgl_lahir'];
                    $tinggi_badan=$i['tinggi_badan'];
                    $berat_badan=$i['berat_badan'];
                    $gol_darah=$i['gol_darah'];
                    $agama=$i['agama'];
                    $alamat_rumah=$i['alamat_rumah'];
                    $hp=$i['hp'];
                    $nama_bapak=$i['nama_bapak'];
                    $tinggi_bapak=$i['tinggi_bapak'];
                    $nama_ibu=$i['nama_ibu'];
                    $tinggi_ibu=$i['tinggi_ibu'];
                    $jml_saudara=$i['jml_saudara'];
                    $hobby=$i['hobby'];
                    
                  ?>
	<!--Modal Edit Pengguna-->
        <div class="modal fade" id="ModalEdit<?php echo $id_peserta;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Edit Peserta</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'peserta/peserta/update_peserta'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">

                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Nama</label>
                                        <div class="col-sm-7">
											<input type="hidden" name="id_peserta" value="<?php echo $id_peserta;?>"/>
                                            <input type="text" name="xnama_peserta" class="form-control" id="inputUserName" value="<?php echo $nama_peserta;?>" placeholder="Nama Lengkap" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputEmail3" class="col-sm-4 control-label">Email</label>
                                        <div class="col-sm-7">
                                            <input type="email" name="xemail_peserta" class="form-control" value="<?php echo $email_peserta;?>" id="inputEmail3" placeholder="Email" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inpuNISN" class="col-sm-4 control-label">NISN</label>
                                        <div class="col-sm-7">
                                            <input type="nisn" name="xnisn" class="form-control" value="<?php echo $nisn;?>" id="inputEmail3" placeholder="NISN yang terdaftar " required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Jenis Kelamin</label>
                                        <div class="col-sm-7">
										<?php if($jns_kelamin=='Laki Laki'):?>
                                           <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio1" value="Laki Laki" name="xjenkel" checked>
                                                <label for="inlineRadio1"> Laki Laki </label>
                                            </div>
                                            <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio1" value="Perempuan" name="xjenkel">
                                                <label for="inlineRadio2"> Perempuan </label>
                                            </div>
										<?php else:?>
											<div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio1" value="Laki Laki" name="xjenkel">
                                                <label for="inlineRadio1"> Laki Laki </label>
                                            </div>
                                            <div class="radio radio-info radio-inline">
                                                <input type="radio" id="inlineRadio1" value="Perempuan" name="xjenkel" checked>
                                                <label for="inlineRadio2"> Perempuan </label>
                                            </div>
										<?php endif;?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword3" class="col-sm-4 control-label">Password</label>
                                        <div class="col-sm-7">
                                            <input type="password" name="xpassword" class="form-control" id="inputPassword3" placeholder="Kosong kan Password jika tidak ingin merubah">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPassword4" class="col-sm-4 control-label">Ulangi Password</label>
                                        <div class="col-sm-7">
                                            <input type="password" name="xpassword2" class="form-control" id="inputPassword4" placeholder="Kosong kan Password jika tidak ingin merubah">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Tempat Lahir</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xtmpt_lahir" class="form-control" value="<?php echo $tmpt_lahir;?>" id="inputUserName" placeholder="Tempat Kelahiran" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Tanggal Lahir</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xtgl_lahir" class="form-control" value="<?php echo $tgl_lahir;?>" id="inputUserName" placeholder="Tanggal Lahir Sesuai Format" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Tinggi Badan</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xtinggi_badan" class="form-control" value="<?php echo $tinggi_badan;?>" id="inputUserName" placeholder="Tinggi Badan dalam Centi Meter" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Berat Badan</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xberat_badan" class="form-control" value="<?php echo $tinggi_badan;?>" id="inputUserName" placeholder="Berat Badan dalam Kilo Gram" required>
                                        </div>
                                    </div>
                                     <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Golongan Darah</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xgol_darah" class="form-control" value="<?php echo $gol_darah;?>" id="inputUserName" placeholder="Golongan Darah" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Agama</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xagama" class="form-control" value="<?php echo $agama;?>" id="inputUserName" placeholder="Agama" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Alamat Rumah</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xalamat_rumah" class="form-control" value="<?php echo $alamat_rumah;?>" id="inputUserName" placeholder="Alamat Rumah / Domisili Keluarga" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Nomor HP</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xhp" class="form-control" value="<?php echo $hp;?>" id="inputUserName" placeholder="Nomor HP" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Nama Bapak</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama_bapak" class="form-control" value="<?php echo $nama_bapak;?>" id="inputUserName" placeholder="Nama Bapak Kandung" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Tinggi Bapak</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xtinggi_bapak" class="form-control" value="<?php echo $tinggi_bapak;?>" id="inputUserName" placeholder="Tinggi Bapak" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Nama Ibu</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xnama_ibu" class="form-control" value="<?php echo $nama_ibu;?>" id="inputUserName" placeholder="Nama Ibu Kandung" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Tinggi Ibu</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xtinggi_ibu" class="form-control" value="<?php echo $tinggi_ibu;?>" id="inputUserName" placeholder="Tinggi Ibu Kandung" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Jumlah Saudara</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xjml_saudara" class="form-control" value="<?php echo $jml_saudara;?>" id="inputUserName" placeholder="Jumlah Saudara" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Hobby</label>
                                        <div class="col-sm-7">
                                            <input type="text" name="xhobby" class="form-control" value="<?php echo $hobby;?>" id="inputUserName" placeholder="Hobby" required>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="inputUserName" class="col-sm-4 control-label">Data</label>
                                        <div class="col-sm-7">
                                            <input type="file" name="filefoto"/>
                                        </div>
                                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Update</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
	<?php endforeach;?>

	<?php foreach ($data->result_array() as $i) :
              $pengguna_id=$i['id_peserta'];
              $pengguna_nama=$i['nama_peserta'];
              $pengguna_jenkel=$i['jns_kelamin'];
              $pengguna_email=$i['email_peserta'];
            //  $pengguna_username=$i['pengguna_username'];
            //  $pengguna_password=$i['pengguna_password'];
              $pengguna_nohp=$i['hp'];
              $pengguna_photo=$i['foto_peserta'];
            ?>
	<!--Modal Hapus Pengguna-->
        <div class="modal fade" id="ModalHapus<?php echo $pengguna_id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Hapus Pengguna</h4>
                    </div>
                    <form class="form-horizontal" action="<?php echo base_url().'admin/pengguna/hapus_pengguna'?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
							<input type="hidden" name="kode" value="<?php echo $pengguna_id;?>"/>
                            <p>Apakah Anda yakin mau menghapus Pengguna <b><?php echo $pengguna_nama;?></b> ?</p>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-flat" id="simpan">Hapus</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
	<?php endforeach;?>

	<!--Modal Reset Password-->
        <div class="modal fade" id="ModalResetPassword" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><span class="fa fa-close"></span></span></button>
                        <h4 class="modal-title" id="myModalLabel">Reset Password</h4>
                    </div>

                    <div class="modal-body">

                            <table>
                                <tr>
                                    <th style="width:120px;">Username</th>
                                    <th>:</th>
                                    <th><?php echo $this->session->flashdata('uname');?></th>
                                </tr>
                                <tr>
                                    <th style="width:120px;">Password Baru</th>
                                    <th>:</th>
                                    <th><?php echo $this->session->flashdata('upass');?></th>
                                </tr>
                            </table>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>

                </div>
            </div>
        </div>


<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url().'assets/plugins/jQuery/jquery-2.2.3.min.js'?>"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url().'assets/bootstrap/js/bootstrap.min.js'?>"></script>
<!-- DataTables -->
<script src="<?php echo base_url().'assets/plugins/datatables/jquery.dataTables.min.js'?>"></script>
<script src="<?php echo base_url().'assets/plugins/datatables/dataTables.bootstrap.min.js'?>"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url().'assets/plugins/slimScroll/jquery.slimscroll.min.js'?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url().'assets/plugins/fastclick/fastclick.js'?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url().'assets/dist/js/app.min.js'?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url().'assets/dist/js/demo.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/plugins/toast/jquery.toast.min.js'?>"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
<?php if($this->session->flashdata('msg')=='error'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Error',
                    text: "Password dan Ulangi Password yang Anda masukan tidak sama.",
                    showHideTransition: 'slide',
                    icon: 'error',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#FF4859'
                });
        </script>
    <?php elseif($this->session->flashdata('msg')=='warning'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Warning',
                    text: "Gambar yang Anda masukan terlalu besar.",
                    showHideTransition: 'slide',
                    icon: 'warning',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#FFC017'
                });
        </script>
    <?php elseif($this->session->flashdata('msg')=='success'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Success',
                    text: "Pengguna Berhasil disimpan ke database.",
                    showHideTransition: 'slide',
                    icon: 'success',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#7EC857'
                });
        </script>
    <?php elseif($this->session->flashdata('msg')=='info'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Info',
                    text: "Pengguna berhasil di update",
                    showHideTransition: 'slide',
                    icon: 'info',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#00C9E6'
                });
        </script>
    <?php elseif($this->session->flashdata('msg')=='success-hapus'):?>
        <script type="text/javascript">
                $.toast({
                    heading: 'Success',
                    text: "Pengguna Berhasil dihapus.",
                    showHideTransition: 'slide',
                    icon: 'success',
                    hideAfter: false,
                    position: 'bottom-right',
                    bgColor: '#7EC857'
                });
        </script>
    <?php elseif($this->session->flashdata('msg')=='show-modal'):?>
        <script type="text/javascript">
                $('#ModalResetPassword').modal('show');
        </script>
    <?php else:?>

    <?php endif;?>
</body>
</html>
