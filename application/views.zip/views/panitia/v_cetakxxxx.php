<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<title>WEBSITE</title>
	<link href="js/style_pag.css" rel="stylesheet" type="text/css" />
	<style type="text/css">
/* Kode CSS Untuk PAGE ini dibuat oleh http://jsfiddle.net/2wk6Q/1/ */
    body {
        width: 100%;
        height: 100%;
        margin: 0;
        padding: 0;
        background-color: #FAFAFA;
        font: 12pt "Tahoma";
    }
    * {
        box-sizing: border-box;
        -moz-box-sizing: border-box;
    }
    .page {
        width: 210mm;
        min-height: 297mm;
        padding: 20mm;
        margin: 10mm auto;
        border: 1px #D3D3D3 solid;
        border-radius: 5px;
        background: white;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    }
    .subpage {
        padding: 1cm;
        border: 5px red solid;
        height: 257mm;
        outline: 2cm #FFEAEA solid;
    }
    
    @page {
        size: A4;
        margin: 0;
    }
    @media print {
        html, body {
            width: 210mm;
            height: 297mm;        
        }
        .page {
            margin: 0;
            border: initial;
            border-radius: initial;
            width: initial;
            min-height: initial;
            box-shadow: initial;
            background: initial;
            page-break-after: always;
        }
    }
</style>


	<style type="text/css"><!--
.style3 {
	color: #000000;

	font-weight: bold;

	font-size: 14px;
}
-->
	</style>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" marginheight="0" marginwidth="0" topmargin="0"><!-- ImageReady Slices (WEBSITE.psd) -->
<table border="0" cellpadding="0" cellspacing="0" height="22" id="id=&quot;tbl&quot;" width="1519">
	<tbody>
		<tr>
			<td width="190"></td>
			<td width="785"></td>
		</tr>
	</tbody>
</table>
<?php
	$hasil = $data->row();
	
	                $id_peserta=$hasil->id_peserta;
                    $foto_peserta=$hasil->foto_peserta;
                    $nisn=$hasil->nisn;
                    $nama_peserta=$hasil->nama_peserta;
                    $email_peserta=$hasil->email_peserta;
                    $jns_kelamin=$hasil->jns_kelamin;
                    $tmpt_lahir=$hasil->tmpt_lahir;
                    $tgl_lahir=$hasil->tgl_lahir;
                    $tinggi_badan=$hasil->tinggi_badan;
                    $berat_badan=$hasil->berat_badan;
                    $gol_darah=$hasil->gol_darah;
                    $agama=$hasil->agama;
                    $alamat_rumah=$hasil->alamat_rumah;
                    $hp=$hasil->hp;
                    $nama_bapak=$hasil->nama_bapak;
                    $tinggi_bapak=$hasil->tinggi_bapak;
                    $nama_ibu=$hasil->nama_ibu;
                    $tinggi_ibu=$hasil->tinggi_ibu;
                    $jml_saudara=$hasil->jml_saudara;
                    $hobby=$hasil->hobby;
                    $cabor=$hasil->nm_cabor;
                    $posisi=$hasil->nm_posisi;
                    $barcode=$hasil->barcode;
?>

<table border="0" cellpadding="0" cellspacing="0" height="549" id="Table_01" width="366">
	<tbody>
		<tr>
			<td><img alt="" height="237" src="<?php echo base_url() ?>/theme/images/img_kartu/BOLA_01.gif" width="141" /></td>
			<td><img alt="" height="237" src="<?php echo base_url() ?>/theme/images/img_kartu/BOLA_02.gif" width="110" /></td>
			<td><img alt="" height="237" src="<?php echo base_url() ?>/theme/images/img_kartu/BOLA_03.gif" width="115" /></td>
		</tr>
		<tr>
			<td><img alt="" height="140" src="<?php echo base_url() ?>/theme/images/img_kartu/BOLA_04.gif" width="141" /></td>
			<td>
			<center><img width="10" height="10"  src="<?php echo base_url().'assets/images/'.$foto_peserta?>"?></center>
			</td>
			<td><img alt="" height="140" src="<?php echo base_url() ?>/theme/images/img_kartu/BOLA_06.gif" width="115" /></td>
		</tr>
		<tr>
			<td><img alt="" src="<?php echo base_url() ?>/theme/images/img_kartu/BOLA_07.gif" style="width: 141px; height: 46px;" /></td>
			<td background="<?php echo base_url() ?>/theme/images/img_kartu/BOLA_08.gif" colspan="2"><font color="#FF0000" ><?php echo $cabor;?></font><br />
			<strong><font color="#FF0000"> <?php echo $nama_peserta;?></font></strong></td>
		</tr>
		<tr>
			<td><img alt="" height="34" src="<?php echo base_url() ?>/theme/images/img_kartu/BOLA_09.gif" width="141" /></td>
			<td background="http://sapasko.id/img_kartu/BOLA_10.gif" colspan="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		</tr>
		<tr>
			<td><img alt="" height="92" src="<?php echo base_url() ?>/theme/images/img_kartu/BOLA_11.gif" width="141" /></td>
			<td colspan="2"><img alt="" height="92" src="<?php echo base_url() ?>/theme/images/img_kartu/BOLA_12.gif" width="225" /></td>
		</tr>
	</tbody>
</table>
<!-- End ImageReady Slices -->

<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<tbody>
		<tr>
			<td height="8"></td>
		</tr>
	</tbody>
</table>
</body>
</html>
<script type="text/javascript">window.print();</script>