<HTML>
<HEAD>
<TITLE>Id 21</TITLE>
<style type="text/css">
/* Kode CSS Untuk PAGE ini dibuat oleh http://jsfiddle.net/2wk6Q/1/ */
    body {
        width: 100%;
        height: 100%;
        margin: 0;
        padding: 0;
        background-color: #FAFAFA;
        font: 12pt "Tahoma";
    }
    * {
        box-sizing: border-box;
        -moz-box-sizing: border-box;
    }
    .page {
        width: 210mm;
        min-height: 297mm;
        padding: 20mm;
        margin: 10mm auto;
        border: 1px #D3D3D3 solid;
        border-radius: 5px;
        background: white;
        box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    }
    .subpage {
        padding: 1cm;
        border: 5px red solid;
        height: 257mm;
        outline: 2cm #FFEAEA solid;
    }
    
    @page {
        size: A4;
        margin: 0;
    }
    @media print {
        html, body {
            width: 210mm;
            height: 297mm;        
        }
        .page {
            margin: 0;
            border: initial;
            border-radius: initial;
            width: initial;
            min-height: initial;
            box-shadow: initial;
            background: initial;
            page-break-after: always;
        }
    }
    </style>
   
<style type="text/css">
<!--
.style4 {
	color: #0000FF;
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style16 {font-family: Arial, Helvetica, sans-serif; font-weight: bold; }
.style18 {color: #0000FF; font-family: Arial, Helvetica, sans-serif; }
.style14 {font-family: Arial, Helvetica, sans-serif}
-->
</style>
</HEAD>
<BODY BGCOLOR=#FFFFFF LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
<?php
	$hasil = $data->row();
	
	                $id_peserta=$hasil->id_peserta;
                    $foto_peserta=$hasil->foto_peserta;
                    $nisn=$hasil->nisn;
                    $nama_peserta=$hasil->nama_peserta;
                    $email_peserta=$hasil->email_peserta;
                    $jns_kelamin=$hasil->jns_kelamin;
                    $tmpt_lahir=$hasil->tmpt_lahir;
                    $tgl_lahir=$hasil->tgl_lahir;
                    $tinggi_badan=$hasil->tinggi_badan;
                    $berat_badan=$hasil->berat_badan;
                    $gol_darah=$hasil->gol_darah;
                    $agama=$hasil->agama;
                    $alamat_rumah=$hasil->alamat_rumah;
                    $hp=$hasil->hp;
                    $nama_bapak=$hasil->nama_bapak;
                    $tinggi_bapak=$hasil->tinggi_bapak;
                    $nama_ibu=$hasil->nama_ibu;
                    $tinggi_ibu=$hasil->tinggi_ibu;
                    $jml_saudara=$hasil->jml_saudara;
                    $hobby=$hasil->hobby;
                    $cabor=$hasil->nm_cabor;
                    $posisi=$hasil->nm_posisi;
                    $barcode=$hasil->barcode;
?>

<!-- ImageReady Slices (Id 21.psd) -->
<TABLE WIDTH=1326 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD COLSPAN=10>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_01.gif'?>" WIDTH=1326 HEIGHT=132 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=132 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=2 ROWSPAN=11>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_02.gif'?>" WIDTH=235 HEIGHT=493 ALT=""></TD>
		<TD COLSPAN=3 background="<?php echo base_url().'?>theme/images/images/sapaok_03.gif'?>"><span class="style18"><?php echo "$id_peserta"; ?></span> </TD>
		<TD COLSPAN=5 ROWSPAN=2>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_04.gif'?>" WIDTH=781 HEIGHT=56 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=44 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=3>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_05.gif'?>" WIDTH=310 HEIGHT=12 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=12 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=3 background="<?php echo base_url().'images/sapaok_06.gif'?>"><span class="style14"><?php echo "$nama_peserta"; ?></span> </TD>
		<TD ROWSPAN=15>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_07.gif'?>" WIDTH=160 HEIGHT=747 ALT=""></TD>
		<TD COLSPAN=3 background="<?php echo base_url().'theme/images/images/sapaok_08.gif'?>"><span class="style18"><?php echo "$id_peserta"; ?></span> </TD>
		<TD ROWSPAN=15>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_09.gif'?>" WIDTH=35 HEIGHT=747 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=31 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=3>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_10.gif'?>" WIDTH=310 HEIGHT=16 ALT=""></TD>
		<TD COLSPAN=3>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_11.gif'?>" WIDTH=586 HEIGHT=16 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=16 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=3 background="<?php echo base_url().'theme/images/images/sapaok_12.gif'?>"><span class="style14"><?php echo "$tgl_lahir"; ?></span> </TD>
		<TD COLSPAN=3 background="<?php echo base_url().'theme/images/images/sapaok_13.gif'?>"><span class="style14"><?php echo "$nama_peserta"; ?></span> </TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=29 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=3>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_14.gif'?>" WIDTH=310 HEIGHT=13 ALT=""></TD>
		<TD COLSPAN=3 ROWSPAN=2>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_15.gif'?>" WIDTH=586 HEIGHT=14 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=13 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=3 ROWSPAN=2 background="<?php echo base_url().'theme/images/images/sapaok_16.gif'?>"><span class="style14"><?php echo "$nisn"; ?></span> </TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=1 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=3 background="<?php echo base_url().'theme/images/images/sapaok_17.gif'?>"><span class="style14"><?php echo "$nisn"; ?></span> </TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=32 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=3>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_18.gif'?>" WIDTH=310 HEIGHT=158 ALT=""></TD>
		<TD COLSPAN=3 ROWSPAN=7>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_19.gif'?>" WIDTH=586 HEIGHT=484 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=158 ALT=""></TD>
	</TR>
	<TR>
		<TD ROWSPAN=2>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_20.gif'?>" WIDTH=64 HEIGHT=157 ALT=""></TD>
		<TD background="<?php echo base_url().'theme/images/images/sapaok_21.gif'?>"><img width="103" height="131"  src="<?php echo base_url().'assets/images/'.$foto_peserta?>"?>	  </TD>
		<TD ROWSPAN=2>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_22.gif'?>" WIDTH=143 HEIGHT=157 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=131 ALT=""></TD>
	</TR>
	<TR>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_23.gif'?>" WIDTH=103 HEIGHT=26 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=26 ALT=""></TD>
	</TR>
	<TR>
		<TD ROWSPAN=6>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_24.gif'?>" WIDTH=169 HEIGHT=310 ALT=""></TD>
	  <TD COLSPAN=4 background="<?php echo base_url().'theme/images/images/sapaok_25.gif'?>"><div align="center"><span class="style4"><?php echo "$id_peserta"; ?></span> </div></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=42 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=4 background="<?php echo base_url().'theme/images/images/sapaok_26.gif'?>"><div align="center"><span class="style16"><?php echo "$nama_peserta"; ?></span> </div></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=38 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=4 background="<?php echo base_url().'theme/images/images/sapaok_27.gif'?>"><div align="center"><span class="style16">NISN.  <?php echo "$nisn"; ?></span> </div></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=46 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=4 background="<?php echo base_url().'theme/images/images/sapaok_28.gif'?>"><div align="center"><span class="style16"><?php echo "$cabor"; ?></span> </div></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=43 ALT=""></TD>
	</TR>
	<TR>
		<TD COLSPAN=2 ROWSPAN=2>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_29.gif'?>" WIDTH=130 HEIGHT=141 ALT=""></TD>
		<TD background="<?php echo base_url().'theme/images/images/sapaok_30.gif'?>"><div align="center"><img width="88" height="88"  src="<?php echo base_url().'assets/images/'.$barcode;?>"?>	  </div></TD>
		<TD ROWSPAN=2>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_31.gif'?>" WIDTH=143 HEIGHT=141 ALT=""></TD>
		<TD ROWSPAN=2>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_32.gif'?>" WIDTH=229 HEIGHT=141 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_33.gif'?>" WIDTH=107 HEIGHT=89 ALT=""></TD>
		<TD ROWSPAN=2>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_34.gif'?>" WIDTH=250 HEIGHT=141 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=89 ALT=""></TD>
	</TR>
	<TR>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_35.gif'?>" WIDTH=103 HEIGHT=52 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/sapaok_36.gif'?>" WIDTH=107 HEIGHT=52 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=1 HEIGHT=52 ALT=""></TD>
	</TR>
	<TR>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=169 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=66 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=64 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="i<?php echo base_url().'theme/images/mages/spacer.gif'?>" WIDTH=103 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=143 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=160 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=229 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=107 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'theme/images/images/spacer.gif'?>" WIDTH=250 HEIGHT=1 ALT=""></TD>
		<TD>
			<IMG SRC="<?php echo base_url().'>theme/images/images/spacer.gif'?>" WIDTH=35 HEIGHT=1 ALT=""></TD>
		<TD></TD>
	</TR>
</TABLE>
<!-- End ImageReady Slices -->
</BODY>
</HTML>