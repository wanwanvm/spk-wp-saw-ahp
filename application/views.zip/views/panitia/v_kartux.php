<html>
<head>
	<title></title>
</head>
<body>
<p>Kartu Peserta Pendaftaran</p>

<p>Foto</p>

<table border="0" cellpadding="0" cellspacing="0" height="168" width="424">
	<tbody>
		<tr>
			<td>Nomor Pendaftaran</td>
			<td style="text-align: center;">:</td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		</tr>
		<tr>
			<td>Nama</td>
			<td style="text-align: center;">:</td>
			<td></td>
		</tr>
		<tr>
			<td>NISN</td>
			<td style="text-align: center;">:</td>
			<td></td>
		</tr>
		<tr>
			<td>Cabang Olahraga</td>
			<td style="text-align: center;">:</td>
			<td></td>
		</tr>
		<tr>
			<td>Kelas</td>
			<td style="text-align: center;">:</td>
			<td></td>
		</tr>
		<tr>
			<td>Umur</td>
			<td style="text-align: center;">:</td>
			<td></td>
		</tr>
		<tr>
			<td>Tanggal Lahir</td>
			<td style="text-align: center;">:</td>
			<td></td>
		</tr>
		<tr>
			<td></td>
			<td style="text-align: center;"></td>
			<td></td>
		</tr>
	</tbody>
</table>

<p></p>

<p></p>
</body>
</html>