<?php
 $this->load->helper(array('form', 'url'));
$this->load->library('form_validation');

?>
<!DOCTYPE html>
<html lang="en">

<head>
<!-- Custom CSS -->
    
<!-- Font -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
	 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
	 
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.1/js/tempusdominus-bootstrap-4.min.js"></script>
	
<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bs-custom-file-input/dist/bs-custom-file-input.min.js"></script>
	
	 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
 
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Registrasi Sapa-SKO</title>
    <link rel="shorcut icon" href="<?php echo base_url().'theme/images/logo-dark.png'?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/bootstrap.min.css'?>">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/font-awesome.min.css'?>">
    <!-- Simple Line Font -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/simple-line-icons.css'?>">
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/slick.css'?>">
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/slick-theme.css'?>">
    <link rel="stylesheet" href="<?php echo base_url().'theme/css/owl.carousel.min.css'?>">
    <!-- Main CSS -->
    <link href="<?php echo base_url().'theme/css/style.css'?>" rel="stylesheet">
<link href="<?php echo base_url('assets/bootstrap_datepicker/css/datepicker.css'); ?>" rel="stylesheet">






<style type="text/css">
<!--
.style2 {font-weight: bold}
-->
</style>
</head>

<body>
    <!--============================= HEADER =============================-->
     <?php
    $this->load->view('depan/atas');
  ?>

<!--//END HEADER -->
<!--//END ABOUT IMAGE -->
 
<div class="container">
<div class="row justify-content-center">
<div class="col-lg-10">
<div class="rounded border my-3 bg-white py-3">
<form action="<?php echo base_url().'registrasi/inputpeserta'?>" method="post" enctype="multipart/form-data">

	<?php echo validation_errors(); ?>
     <?php  echo $this->session->flashdata('succses'); ?>
     <?php echo $this->session->flashdata('msg');?>

							<h4 align="center" class="px-4 text-muted style1 style2 "><strong>FORMULIR PROPOSAL PENGHARGAAN  </strong></h4>
							<p class="px-4 text-muted style1 style2"><font color="#0033FF">Pastikan untuk mengisi formulir pendaftaran dengan data yang sebenar benarnya dan dapat di pertanggungjawabkan secara hukum.</font></p>
							<hr>

							<div class="px-4">

								<h5 class="mb-3"><strong>Biodata Olahragawan Berprestasi </strong></h5>
								
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="name">Nama Lengkap</label>
										<input type="text" class="form-control" id="nama" name="nama" required>
									</div>
									<div class="form-group col-md-3">
										<label for="nisn">NO NIK </label>
										<input type="text" class="form-control" id="nik" name="nik" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required>
									</div>
									<div class="form-group col-md-3">
										<label for="nisn">NO NPWP </label>
										<input type="text" class="form-control" id="npwp" name="npwp" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required>
									</div>
									
								</div>
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="tmp_lahir">Tempat Lahir</label>
										<input type="text" class="form-control" id="tmp_lahir" name="tmp_lahir" required>
									</div>
									<div class="form-group col-md-6">
										<label for="tgl_lahir">Tanggal Lahir</label>
										<div class="input-group">
											<input type="text" class="form-control datetimepicker-input" id="tgl_lahir" data-toggle="datetimepicker" data-target="#datetimepicker" name="tgl_lahir" required />
											<div class="input-group-append">
												<span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
											</div>
										</div>
									</div>
									
								</div>
								
								<div class="form-row">
									<div class="form-group col-md-6">
										<label for="gender">Jenis Kelamin</label>
										<select name="jns_kelamin" id="jns_kelamin" class="form-control" required>
											<option selected disabled>-- Pilih --</option>
											<option value="Laki-Laki">Laki-laki</option>
											<option value="Perempuan">Perempuan</option>
										</select>
									</div>
								<div class="form-group col-md-6">
									<label for="kategori">Cabang Olahraga</label>
										<select name="id_cabor" id="kategori" class="form-control" required>
        								<option value="">-PILIH-</option>
       									 <?php foreach($data->result() as $row):?>
       									 <option value="<?php echo $row->id_cabor;?>">
            							<?php echo $row->nm_cabor;?></option>
      							  <?php endforeach;?>
      							  </select>   	
									</div>
								
								
								
								
								</div>
			
								
						
							  <div class="form-row">
									<div class="form-group col-md-6">
										<label for="tempat_lahir">Pekerjaan /Profesi</label>
										<input type="text" class="form-control" id="pekerjaan" name="pekerjaan" required>
									</div>
									<div class="form-group col-md-6">
										<label for="pendidikan">Pendidikan Terakhir</label>
										<select name="pendidikan" id="jns_kelamin" class="form-control" required>
											<option selected disabled>-- Pilih --</option>
											<option value="SD">SD</option>
											<option value="SMP">SMP</option>
											<option value="SMA">SMA</option>
											<option value="D1">D1</option>
											<option value="D2">D2</option>
											<option value="D3">D3</option>
											<option value="S1">S1</option>
											<option value="S2">S2</option>
											<option value="S3">S3</option>
											
										</select>
									</div>
									
							  </div>
								<h5 class="my-3"><strong>Kontak Person </strong></h5>
								<div class="form-row">
									
									<div class="form-group col-md-4">
										<label for="email">Email Wajib dari GMAIL yang aktif</label>
										<input type="email" class="form-control" id="email" name="email" placeholder="contoh@gmail.com" required>
									</div>
									<div class="form-group col-md-4">
										<label for="no_telp">Nomor Telepon / Handphone</label>
										<input type="text" class="form-control" id="hp" name="hp" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required>
									</div>
									<div class="form-group col-md-4">
										<label for="no_telp">NoTelepon / Handphone Kerabat</label>
										<input type="text" class="form-control" id="hp2" name="hp2" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required>
									</div>
								</div>
								<div class="form-group">
									<label for="alamat">Alamat Lengkap</label>
									<input type="text" class="form-control" id="alamat" name="alamat" required>
								</div>
								
								<h5 class="mt-3"><strong>DATA PRESTASI YANG DI PEROLEH </strong></h5>
								
									<h5 class="mt-3"><strong>Single Event Asia Tenggara </strong></h5>
								<div id="prestasi-div">
									<div class="form-row" id="prestasi-row">
										<div class="form-group col-md-3">
											<label for="seatnama">Nama Kejuaraan</label>
											<input type="text" class="form-control" id="seatnama" name="seatnama" >
										</div>
											<div class="form-group col-md-4">
											<label for="seattempat">Tempat Kejuaraan</label>
											<input type="text" class="form-control" id="seattempat" name="seattempat" >
										</div>
										<div class="form-group col-md-3">
											<label for="seatperingkat">Peringkat/Medali</label>
											<input type="text" class="form-control" id="seatperingkat" name="seatperingkat" >
										</div>
											<div class="form-group col-md-2">
											<label for="seattahun">Tahun</label>
											<input type="text" class="form-control" id="seattahun" name="seattahun" >
										</div>
										
										
									</div>
									</div>
									
										<h5 class="mt-3"><strong>Multi Event Asia Tenggara </strong></h5>
								<div id="prestasi-div">
									<div class="form-row" id="prestasi-row">
										<div class="form-group col-md-3">
											<label for="meatnama">Nama Kejuaraan</label>
											<input type="text" class="form-control" id="meatnama" name="meatnama" >
										</div>
											<div class="form-group col-md-4">
											<label for="meattempat">Tempat Kejuaraan</label>
											<input type="text" class="form-control" id="meattempat" name="meattempat" >
										</div>
										<div class="form-group col-md-3">
											<label for="meatperingkat">Peringkat/Medali</label>
											<input type="text" class="form-control" id="meatperingkat" name="meatperingkat" >
										</div>
											<div class="form-group col-md-2">
											<label for="meattahun">Tahun</label>
											<input type="text" class="form-control" id="meattahun" name="meattahun" >
										</div>
									</div>
										</div>
										<h5 class="mt-3"><strong>Single Event Asia  </strong></h5>
								<div id="prestasi-div">
									<div class="form-row" id="prestasi-row">
										<div class="form-group col-md-3">
											<label for="seanama">Nama Kejuaraan</label>
											<input type="text" class="form-control" id="seanama" name="seanama" >
										</div>
											<div class="form-group col-md-4">
											<label for="seatempat">Tempat Kejuaraan</label>
											<input type="text" class="form-control" id="seatempat" name="seatempat" >
										</div>
										<div class="form-group col-md-3">
											<label for="juara">Peringkat/Medali</label>
											<input type="text" class="form-control" id="seaperingkat" name="seaperingkat" >
										</div>
											<div class="form-group col-md-2">
											<label for="juara">Tahun</label>
											<input type="text" class="form-control" id="seatahun" name="seatahun" >
										</div>
										</div>
										</div>
										<h5 class="mt-3"><strong>Multi Event Asia  </strong></h5>
								<div id="prestasi-div">
									<div class="form-row" id="prestasi-row">
										<div class="form-group col-md-3">
											<label for="meanama">Nama Kejuaraan</label>
											<input type="text" class="form-control" id="meanama" name="meanama" >
										</div>
											<div class="form-group col-md-4">
											<label for="meatempat">Tempat Kejuaraan</label>
											<input type="text" class="form-control" id="meatempat" name="meatempat" >
										</div>
										<div class="form-group col-md-3">
											<label for="meaperingkat">Peringkat/Medali</label>
											<input type="text" class="form-control" id="meaperingkat" name="meaperingkat" >
										</div>
											<div class="form-group col-md-2">
											<label for="meatahun">Tahun</label>
											<input type="text" class="form-control" id="meatahun" name="meatahun" >
										</div>
										</div>
										<h5 class="mt-3"><strong>Single Event Dunia </strong></h5>
								<div id="prestasi-div">
									<div class="form-row" id="prestasi-row">
										<div class="form-group col-md-3">
											<label for="sednama">Nama Kejuaraan</label>
											<input type="text" class="form-control" id="sednama" name="sednama" >
										</div>
											<div class="form-group col-md-4">
											<label for="sedtempat">Tempat Kejuaraan</label>
											<input type="text" class="form-control" id="sedtempat" name="sedtempat" >
										</div>
										<div class="form-group col-md-3">
											<label for="sedperingkat">Peringkat/Medali</label>
											<input type="text" class="form-control" id="sedperingkat" name="sedperingkat" >
										</div>
											<div class="form-group col-md-2">
											<label for="sedtahun">Tahun</label>
											<input type="text" class="form-control" id="sedtahun" name="sedtahun" >
										</div>
										</div>
										</div>
										<h5 class="mt-3"><strong>Multi Event Dunia </strong></h5>
								<div id="prestasi-div">
									<div class="form-row" id="prestasi-row">
										<div class="form-group col-md-3">
											<label for="mednama">Nama Kejuaraan</label>
											<input type="text" class="form-control" id="mednama" name="mednama" >
										</div>
											<div class="form-group col-md-4">
											<label for="medtempat">Tempat Kejuaraan</label>
											<input type="text" class="form-control" id="medtempat" name="medtempat" >
										</div>
										<div class="form-group col-md-3">
											<label for="juara">Peringkat/Medali</label>
											<input type="text" class="form-control" id="medperingkat" name="medperingkat" >
										</div>
											<div class="form-group col-md-2">
											<label for="medtahun">Tahun</label>
											<input type="text" class="form-control" id="medtahun" name="medtahun" >
										</div>
										
									</div>
							</div>
							
							
								<h5 class="my-3"><strong>Unggah Dokumen </strong></h5>
								<div class="form-row">
								    	
									<div class="form-group col-md-12">
											<label for="up_rekomendasi">Surat Rekomendasi/ Proposal [.pdf Maksimal 2 MB]</label>
											<div class="custom-file">
												<input type="file" class="custom-file-input" data-tipe_file="pdf" id="up_rekomendasi" name="up_rekomendasi" >
												<label class="custom-file-label" for="customFile">Pilih Berkas</label>
											</div>
								  </div>
										<div class="form-group col-md-12">
											<label for="up_ktp">KTP [.pdf Maksimal 2 MB]</label>
											<div class="custom-file">
												<input type="file" class="custom-file-input" data-tipe_file="pdf" id="up_ktp" name="up_ktp" >
												<label class="custom-file-label" for="customFile">Pilih Berkas</label>
											</div>
								  </div>
										<div class="form-group col-md-12">
											<label for="up_sertifikat">Sertifikat / Piagam Penghargaan [.pdf Maksimal 2 MB]</label>
											<div class="custom-file">
												<input type="file" class="custom-file-input" data-tipe_file="pdf" id="up_sertifikat" name="up_sertifikat" >
												<label class="custom-file-label" for="customFile">Pilih Berkas</label>
											</div>
								  </div>
								</div>
			
					
					<div class="form-row">
					<div class="form-group col-md-2">
						
							<button type="submit" class="btn btn-danger">Kirim <i class="fas fa-angle-double-down"></i></button>
							
					</div>
					<div class="form-group col-md-10">
						
							
							<label class="form-check-label">
            <input class="form-check-input" type="checkbox" required> centang disini untuk setuju | <font color="#FF0000">periksa kembali data dengan benar sebelum anda menyimpan, data yang sudah tersimpan tidak dapat di rubah kembali. </font>
          </label>
					</div>
					
				</div></form>
		</div>
	  </div>
</div>
</div>
</div>

<!--============================= WELCOME TITLE =============================-->
    <!--//END WELCOME TITLE -->
        <!--============================= DETAILED CHART =============================-->

    <!--//END DETAILED CHART -->

        <!--============================= FOOTER =============================-->
       
    <?php
    $this->load->view('depan/bawah');
  ?>
 
                <!--//END FOOTER -->
                <!-- jQuery, Bootstrap JS. -->
    
                
                
                <script src="<?php echo base_url().'theme/js/jquery.min.js'?>"></script>
                <script src="<?php echo base_url().'theme/js/tether.min.js'?>"></script>
                <script src="<?php echo base_url().'theme/js/bootstrap.min.js'?>"></script>
                <!-- Plugins -->
                <script src="<?php echo base_url().'theme/js/slick.min.js'?>"></script>
                <script src="<?php echo base_url().'theme/js/waypoints.min.js'?>"></script>
                <script src="<?php echo base_url().'theme/js/counterup.min.js'?>"></script>
                <script src="<?php echo base_url().'theme/js/owl.carousel.min.js'?>"></script>
                <script src="<?php echo base_url().'theme/js/validate.js'?>"></script>
                <script src="<?php echo base_url().'theme/js/tweetie.min.js'?>"></script>
                <!-- Subscribe -->
                <script src="<?php echo base_url().'theme/js/subscribe.js'?>"></script>
                <!-- Script JS -->
                <script src="<?php echo base_url().'theme/js/script.js'?>"></script>
                <script src="<?php echo base_url().'assets/bootstrap_datepicker/js/bootstrap-datepicker.js'?>"></script>
                
   
        <script type="text/javascript">
        
        //membuat data posisi
    $(document).ready(function(){
        $('#kategori').change(function(){
            var id=$(this).val();
            $.ajax({
                url : "<?php echo base_url();?>index.php/registrasi/get_posisi",
                method : "POST",
                data : {id: id},
                async : false,
                dataType : 'json',
                success: function(data){
                    var html = '';
                    var i;
                    for(i=0; i<data.length; i++){
                        html += '<option value='+data[i].id_psb+'>'+data[i].nm_posisi+'</option>';
                    }
                    $('.kelas').html(html);
                    
                }
            });
        });
    });

   
</script>
<script type="text/javascript">
/**
     * Date picker.
     */
    // Tanggal Lahir.
    $('#tgl_lahir').datepicker({
        format: "dd-mm-yyyy",
        autoclose: true,
        todayHighlight:true,
        startView:'decade'
    });
</script>
<script>

	// SUBMIT
	function submit_register() {
		document.forms.registerForm.submit();
	}

	$(document).ready(function() {
		bsCustomFileInput.init()
	})

	// Validasi File
	$('.custom-file-input').change(function() {
		pic_size = $(this)[0].files[0].size;
		type = $(this).val().split('.').pop();
		tipe_file = $(this).data('tipe_file');
		if (tipe_file == 'foto') {
			var arrType = ['jpg', 'png', 'jpeg']
			if (!arrType.includes(type)) {
				Swal.fire(
					
					'Tipe file harus .jpg, .png, .jpeg dan besar file maksimal 2 MB'
					
				)
				$(this).val('')
				return;
			}
		} else {
			if (type != 'pdf') {
				Swal.fire(
					
					'Tipe file harus .pdf dan Besar file maksimal 2 MB'
					
				)
				$(this).val('')
				return;
			}
		}
		if (pic_size > 2000000) {
			Swal.fire(
				'Ukuran file maksimal 2 MB',
				'error',
				'error'
			)
			$(this).val('')
			return;
		}
	})
</script>
            </body>

            </html>
