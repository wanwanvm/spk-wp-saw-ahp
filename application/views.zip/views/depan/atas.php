<style type="text/css">
<!--
.style1 {font-family: Arial, Helvetica, sans-serif}
-->
</style>
    <div class="header-topbar">
        <div class="container">
            <div class="row">
                <div class="col-xs-6 col-sm-8 col-md-9">
                    <div class="header-top_address">
                        <div class="header-top_list">
                            <span class="icon-phone"></span> 021 
                        </div>
                        <div class="header-top_list">
                            <span class="icon-envelope-open"></span>info@gmail.com 
                        </div>
                        
                    </div>
                
                </div>
                
            </div>
        </div>
    </div>
    <div data-toggle="affix">
        <div class="container nav-menu2">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar2 navbar-toggleable-md navbar-light bg-faded">
                        <button class="navbar-toggler navbar-toggler2 navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown">
                            <span class="icon-menu"></span>
                        </button>
                        <a href="<?php echo site_url('');?>" class="navbar-brand nav-brand2"><img class="img img-responsive" width="50px;" src="<?php echo base_url().'theme/images/logosapa.png'?>"></a>
                        <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                <span class="style1"><a class="nav-link" href="<?php echo site_url('');?>">Home</a>                                    </span></li>
                                <li class="nav-item style1">
                                    <a class="nav-link" href="<?php echo site_url('persyaratan');?>">Persyaratan</a>                                </li>
                                 <li class="nav-item style1">
                                    <a class="nav-link" href="<?php echo site_url('registrasi');?>">Formulir Proposal </a>                                </li>
                                 <li class="nav-item style1">
                                    <a class="nav-link" href="<?php echo site_url('adminpeserta');?>">Cek Proposal </a>                                </li>

                               
                                <li class="nav-item">
                                  <span class="style1"><a class="nav-link" href="<?php echo site_url('contact');?>">Hubungi Kami</a></span>                                </li>
                          </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
      </div>
