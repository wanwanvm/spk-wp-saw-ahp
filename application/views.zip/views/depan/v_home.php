<html>
<head><meta charset="utf-8">
	<title></title>
</head>
<body>
<p>Maaf anda tidak berhak menghakses <a href="http://avisasys.net/e-proposal/edatabase/adminpanitia">klik di sini untuk login</a></p>
</body>
</html>