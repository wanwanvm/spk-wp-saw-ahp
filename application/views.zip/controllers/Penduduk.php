<?php
class Penduduk extends CI_Controller {
 
	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_penduduk');
	}
 
	public function index()
	{
		$data['graph'] = $this->m_penduduk->graph();
		$this->load->view('v_chart', $data);
	}
 
}