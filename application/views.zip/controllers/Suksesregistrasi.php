<?php
class Suksesregistrasi extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_pengunjung');
		//$this->load->model('m_registrasi');
		$this->m_pengunjung->count_visitor();
		
	}
	function index(){
		$x['tot_pelatih']=$this->db->get('tbl_pelatih')->num_rows();
		$x['tot_atlet']=$this->db->get('tbl_atlet')->num_rows();
		$x['tot_files']=$this->db->get('tbl_files')->num_rows();
		$x['tot_agenda']=$this->db->get('tbl_agenda')->num_rows();
		
		
	   // $id_peserta=$this->input->post('id_peserta');
		//$x['data']=$this->m_registrasi->get_sukses_registrasi();
		$this->load->view('depan/v_suksesregistrasi',$x);
	}
}
