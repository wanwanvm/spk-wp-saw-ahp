<?php
class Registrasi extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_pengunjung');
		$this->m_pengunjung->count_visitor();
	    $this->load->model('m_registrasi');
	    $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));
       $this->load->library('session');
		
	}
	function index(){
	     $x['data']=$this->m_registrasi->get_cabor();
        $x['kode'] = $this->m_registrasi->kode();
	//	$x['tot_pelatih']=$this->db->get('tbl_pelatih')->num_rows();
	//	$x['tot_atlet']=$this->db->get('tbl_atlet')->num_rows();
		//$x['tot_files']=$this->db->get('tbl_files')->num_rows();
		//$x['tot_agenda']=$this->db->get('tbl_agenda')->num_rows();
		//kode otomatis
		
		$this->load->view('depan/v_registrasi',$x);
		
		
		    
		}

    function get_posisi(){
        $id=$this->input->post('id');
        $data=$this->m_registrasi->get_posisi($id);
        echo json_encode($data);
    }
    
    
    //fungsi kode otomatis
    public function inputpeserta(){
            
    $this->form_validation->set_rules('id_cabor','Cabor','required');
   /* $this->form_validation->set_rules('kelas','Kelas','required');
    $this->form_validation->set_rules('nisn','Nisn','required');        
    $this->form_validation->set_rules('nama_peserta','Nama Peserta','required');
	$this->form_validation->set_rules('alamat_rumah','Alamat Peserta','required');
	$this->form_validation->set_rules('email_peserta','Email Peserta','required|valid_email');
	$this->form_validation->set_rules('jns_kelamin','Jenis Kelamin','required');
    $this->form_validation->set_rules('tmpt_lahir','Tempat Lahir','required');
	$this->form_validation->set_rules('tgl_lahir','Tanggal Lahir','required');
	$this->form_validation->set_rules('tinggi_badan','Tinggi Badan','required');
	$this->form_validation->set_rules('berat_badan','Berat Badan','required');
	$this->form_validation->set_rules('gol_darah','Golongan Darah','required');
	$this->form_validation->set_rules('hp','Handphone','required');
	$this->form_validation->set_rules('nama_bapak','Nama Bapak','required');
	$this->form_validation->set_rules('nama_ibu','Nama Ibu','required');
	*/

   // $this->form_validation->set_rules('password','Password','required|min_length[5]'); // min_length[5] password tidak boleh kurang dari lima
   // $this->form_validation->set_rules('retypepassword','Retype Password','required|min_length[5]|matches[password]'); // matches[password] 
    //$this->form_validation->set_rules('konfir_email','Konfirmasi Email','required');
	
	
	//perhitungan tanggal lahir  
	$tgl_lahir=$this->input->post('tgl_lahir');
	//$kelas=$this->input->post('kelas');
	//$tinggi_badan=$this->input->post('tinggi_badan');
	//$berat_badan=$this->input->post('berat_badan');
	//$jns_kelamin=$this->input->post('jns_kelamin');
	$this->load->helper('ppdb_helper');
    $tanggalx = date_to_en($tgl_lahir);
	$tgl_a = date('Y', strtotime($tanggalx));
   
            //batas nisn
 
    if($this->form_validation->run() != false){

        if($_POST){
		
				//upload pas foto
			$this->load->library('upload');
			/*	$config['upload_path'] = './assets/images/'; //path folder
	            $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
	            $config['encrypt_name'] = TRUE; //nama yang terupload nantinya
				$this->upload->initialize($config);
	            $this->upload->do_upload('pas_foto');
				$gbr = $this->upload->data();
	                        //Compress Image
	             		 $config['image_library']='gd2';
	                        $config['source_image']='./assets/images/'.$gbr['file_name'];
	                        $config['create_thumb']= FALSE;
	                        $config['maintain_ratio']= FALSE;
	                        $config['quality']= '60%';
	                        $config['width']= 250;
	                        $config['height']= 400;
	                        $config['new_image']= './assets/images/'.$gbr['file_name'];
	                        $this->load->library('image_lib', $config);
	                        $this->image_lib->resize();
	               			$gambar=$gbr['file_name'];
	               			*/
			//batas bawah pas foto
			//batas atas up rekomendasi
			
			 $config1['upload_path'] = './assets/files/'; //path folder
	        $config1['allowed_types'] = 'pdf'; //type yang dapat diakses bisa anda sesuaikan
	       $config1['encrypt_name'] = TRUE; //nama yang terupload nantinya
        $this->upload->initialize($config1);
	       $this->upload->do_upload('up_rekomendasi');
	        $gbr1 = $this->upload->data();
	       $file_up_rekomendasi=$gbr1['file_name'];
							//$judul=strip_tags($this->input->post('xjudul'));
							//$deskripsi=$this->input->post('xdeskripsi');
							//$oleh=strip_tags($this->input->post('xoleh'));
	
							//$this->m_files->simpan_file($judul,$deskripsi,$oleh,$file);
							//echo $this->session->set_flashdata('msg','success');
							//redirect('admin/files');
			
			//batas bawah up rekomendasi
			//up ktp
			$config2['upload_path'] = './assets/files/'; //path folder
	            $config2['allowed_types'] = 'pdf'; //type yang dapat diakses bisa anda sesuaikan
	            $config2['encrypt_name'] = TRUE; //nama yang terupload nantinya

	            $this->upload->initialize($config2);
	              $this->upload->do_upload('up_ktp');
	           $gbr2 = $this->upload->data();
	                        $file_up_ktp=$gbr2['file_name'];
			//batas bawah up KTP
			//up ktp
			$config3['upload_path'] = './assets/files/'; //path folder
	            $config3['allowed_types'] = 'pdf'; //type yang dapat diakses bisa anda sesuaikan
	            $config3['encrypt_name'] = TRUE; //nama yang terupload nantinya

	            $this->upload->initialize($config3);
	              $this->upload->do_upload('up_sertifikat');
	           $gbr3 = $this->upload->data();
	                        $file_up_sertifikat=$gbr3['file_name'];
			//batas bawah up sertifikat
			
			
                //$barang = $this->input->post('namaBarang');
                //$id_peserta = $this->input->post('id_peserta');
                $id_cabor=$this->input->post('id_cabor');
                $id_jns=1;
                $nama=$this->input->post('nama');
                $nik=$this->input->post('nik');
                $npwp=$this->input->post('npwp');
				$tmp_lahir=$this->input->post('tmp_lahir');
				$tgl_lahir=$this->input->post('tgl_lahir');
				$this->load->helper('ppdb_helper');
                $tanggal = date_to_en($tgl_lahir);
				$jns_kelamin=$this->input->post('jns_kelamin');
				$pekerjaan=$this->input->post('pekerjaan');
				$pendidikan=$this->input->post('pendidikan');
				$email=$this->input->post('email');
				$hp=$this->input->post('hp');
				$hp2=$this->input->post('hp2');
				$alamat=$this->input->post('alamat');
				$seatnama=$this->input->post('seatnama');
				$seattempat=$this->input->post('seattempat');
				$seatperingkat=$this->input->post('seatperingkat');
				$seattahun=$this->input->post('seattahun');
				$meatnama=$this->input->post('meatnama');
				$meattempat=$this->input->post('meattempat');
				$meatperingkat=$this->input->post('meatperingkat');
				$meattahun=$this->input->post('meattahun');
				$seanama=$this->input->post('seanama');
				$seatempat=$this->input->post('seatempat');
				$seaperingkat=$this->input->post('seaperingkat');
				$seatahun=$this->input->post('seatahun');
				$meanama=$this->input->post('meanama');
				$meatempat=$this->input->post('meatempat');
				$meaperingkat=$this->input->post('meaperingkat');
				$meatahun=$this->input->post('meatahun');
				$sednama=$this->input->post('sednama');
				$sedtempat=$this->input->post('sedtempat');
				$sedperingkat=$this->input->post('sedperingkat');
				$sedtahun=$this->input->post('sedtahun');
				$mednama=$this->input->post('mednama');
				$medtempat=$this->input->post('medtempat');
				$medperingkat=$this->input->post('medperingkat');
				$medtahun=$this->input->post('medtahun');
				$tgl_upload = date("Y-m-d H:i:s");
				
				
				
				
				
                // $peserta->tanggal_lahir = $this->load->helper('ppdb_helper'); date_to_en($peserta->tanggal_lahir);
                
               
               
			   // $stok = $this->input->post('stokBarang');
                $kode = $this->m_registrasi->kode();
               $password = date('dmY', strtotime($tgl_lahir));
             //  $password=$this->input->post('password');
                
                //$sandi=md5($password);
            $sandi = password_hash($password, PASSWORD_DEFAULT); 
                 
            //barcode
            
            
		$this->load->library('ciqrcode'); //pemanggilan library QR CODE

		$config['cacheable']	= true; //boolean, the default is true
		$config['cachedir']		= './assets/'; //string, the default is application/cache/
		$config['errorlog']		= './assets/'; //string, the default is application/logs/
		$config['imagedir']		= './assets/images/'; //direktori penyimpanan qr code
		$config['quality']		= true; //boolean, the default is true
		$config['size']			= '1024'; //interger, the default is 1024
		$config['black']		= array(224,255,255); // array, default is array(255,255,255)
		$config['white']		= array(70,130,180); // array, default is array(0,0,0)
		$this->ciqrcode->initialize($config);

		$image_name=$kode.'.png'; //buat name dari qr code sesuai dengan nim

		$params['data'] = $kode; //data yang akan di jadikan QR CODE
		$params['level'] = 'H'; //H=High
		$params['size'] = 10;
		$params['savename'] = FCPATH.$config['imagedir'].$image_name; //simpan image QR CODE ke folder assets/images/
		$this->ciqrcode->generate($params); // fungsi untuk generate QR CODE

         //batas barcode
                $this->m_registrasi->inputpeserta(array( 
               'nama'=> $nama,
                'nik'=>$nik,
                'npwp'=>$npwp,
				'tmp_lahir'=>$tmp_lahir,
                'tgl_lahir'=>$tanggal,
				'jns_kelamin'=>$jns_kelamin,
				'pekerjaan'=>$pekerjaan,
				'pendidikan'=>$pendidikan,
				'email'=>$email,
				'hp'=>$hp,
				'hp2'=>$hp2,
				'alamat'=>$alamat,
				'seatnama'=>$seatnama,
				'seattempat'=>$seattempat,
				'seatperingkat'=>$seatperingkat,
				'seattahun'=>$seattahun,
				'meatnama'=>$meatnama,
				'meattempat'=>$meattempat,
				'meatperingkat'=>$meatperingkat,
				'meattahun'=>$meattahun,
				'seanama'=>$seanama,
				'seatempat'=>$seatempat,
				'seaperingkat'=>$seaperingkat,
				'seatahun'=>$seatahun,
				'meanama'=>$meanama,
				'meatempat'=>$meatempat,
				'meaperingkat'=>$meaperingkat,
				'meatahun'=>$meatahun,
				'sednama'=>$sednama,
				'sedtempat'=>$sedtempat,
				'sedperingkat'=>$sedperingkat,
				'sedtahun'=>$sedtahun,
				'mednama'=>$mednama,
				'medtempat'=>$medtempat,
				'medperingkat'=>$medperingkat,
				'medtahun'=>$medtahun,
				'tgl_upload'=>$tgl_upload, 
			    'id_proposal'=>$kode,
                'id_cabor'=>$id_cabor,
				'id_jns'=>$id_jns,
				'barcode'=>$image_name,
				'up_rekomendasi'=>$file_up_rekomendasi,
				'up_ktp'=>$file_up_ktp,
				'up_sertifikat'=>$file_up_sertifikat
				
                ));
            
           
            
			}
			
		    //echo "Form validation oke";
            $this->session->set_flashdata('succses','Data Yang anda masukan berhasil tersimpan.');
              //  redirect('registrasi');
           $x['kode'] = $kode;   
           $x['email'] = $email;
           $x['nama']=$nama;
		   
              
        $this->load->view('depan/v_suksesregistrasi',$x);
        
    }
	
	else{
        $x['data']=$this->m_registrasi->get_cabor();
        $x['kode'] = $this->m_registrasi->kode();
            
           
            
           $this->load->view('depan/v_registrasi',$x);

    }
	
            
     //batas bawah cek email
        }
        
}
