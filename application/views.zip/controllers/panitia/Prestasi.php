<?php
class prestasi extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masukpanitia') !=TRUE){
            $url=base_url('adminpanitia');
            redirect($url);
        };
		$this->load->model('m_panitiaprestasi');
		$this->load->library('upload');
	}


	function index(){
		$x['data']=$this->m_panitiaprestasi->get_panitia_all_prestasi();
		$this->load->view('panitia/v_prestasi',$x);
	}
	function update_status(){
	//	$id_peserta=strip_tags($this->input->post('id_peserta'));
		$id_prestasi=$this->input->post('id_prestasi');
		$status=strip_tags($this->input->post('xstatus'));
		$keterangan=$this->input->post('xketerangan');
	
		$this->m_panitiaprestasi->update_status($id_prestasi,$status,$keterangan);
		echo $this->session->set_flashdata('msg','info');
		//$id_peserta=strip_tags($this->input->post('id_peserta'));
		redirect('panitia/pesertaall');
	}
	function update_status2(){
		$id_prestasi=strip_tags($this->input->post('id_prestasi'));
		$status=strip_tags($this->input->post('xstatus'));
		$keterangan=$this->input->post('xketerangan');
		$this->m_panitiaprestasi->update_status2($id_prestasi,$status,$keterangan);
		echo $this->session->set_flashdata('msg','info');
		//$id_peserta=strip_tags($this->input->post('id_peserta'));
		redirect('panitia/pesertaall');
	}

	function simpan_prestasi(){
		$nama_prestasi=strip_tags($this->input->post('xnama_prestasi'));
		$juara_prestasi=$this->input->post('xjuara_prestasi');
		$tempat_prestasi=$this->input->post('xtempat_prestasi');
		$tahun=$this->input->post('xtahun');
		$this->m_prestasi->simpan_prestasi($nama_prestasi,$juara_prestasi,$tempat_prestasi,$tahun);
		echo $this->session->set_flashdata('msg','success');
		redirect('peserta/prestasi');
	}

	function update_prestasi(){
	    $id_prestasi=$this->input->post('xid_prestasi');
		$nama_prestasi=$this->input->post('xnama_prestasi');
		$juara_prestasi=$this->input->post('xjuara_prestasi');
		$tempat_prestasi=$this->input->post('xtempat_prestasi');
		$tahun=$this->input->post('xtahun');
		$this->m_prestasi->update_prestasi($id_prestasi,$nama_prestasi,$juara_prestasi,$tempat_prestasi,$tahun);
		echo $this->session->set_flashdata('msg','info');
		redirect('peserta/prestasi');
	}
	function hapus_prestasi(){
		$id_prestasi=$this->input->post('xid_prestasi');
		$this->m_prestasi->hapus_prestasi($id_prestasi);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('peserta/prestasi');
	}

}