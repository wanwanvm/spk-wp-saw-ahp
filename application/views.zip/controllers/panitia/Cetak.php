<?php
class Cetak extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masukpanitia') !=TRUE){
          $url=base_url('adminpanitia');
           redirect($url);
      };
		$this->load->model('m_panitiacetak');
	//	$this->load->library('upload');
	}


	function index(){
		$x['data']=$this->m_panitiacetak->get_peserta();
	//	$this->load->view('peserta/v_link',$x);
	$this->load->view('panitia/v_cetak',$x);
	}


}