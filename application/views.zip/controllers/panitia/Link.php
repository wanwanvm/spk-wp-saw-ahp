<?php
class Link extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masukpanitia') !=TRUE){
            $url=base_url('adminpanitia');
            redirect($url);
        };
		$this->load->model('m_panitialink');
		$this->load->library('upload');
	}


	function index(){
		$x['data']=$this->m_panitialink->get_panitia_all_link();
		$this->load->view('panitia/v_link',$x);
	}
	function update_status(){
		$id_peserta=strip_tags($this->input->post('id_peserta'));
		$status=strip_tags($this->input->post('xstatus'));
		$keterangan=$this->input->post('xketerangan');
		$id_link=$this->input->post('id_link');
		$this->m_panitialink->update_status($id_peserta,$status,$keterangan,$id_link);
		echo $this->session->set_flashdata('msg','info');
		//$id_peserta=strip_tags($this->input->post('id_peserta'));
		redirect('panitia/pesertaall');
	}
	function update_status2(){
		$id_link=strip_tags($this->input->post('id_link'));
		$status=strip_tags($this->input->post('xstatus'));
		$keterangan=$this->input->post('xketerangan');
		$this->m_panitialink->update_status2($id_link,$status,$keterangan);
		echo $this->session->set_flashdata('msg','info');
		//$id_peserta=strip_tags($this->input->post('id_peserta'));
		redirect('panitia/pesertaall');
	}
	function simpan_link(){
		$judul=strip_tags($this->input->post('xjudul'));
		$deskripsi=$this->input->post('xdeskripsi');
		$this->m_link->simpan_link($judul,$deskripsi);
		echo $this->session->set_flashdata('msg','success');
		redirect('peserta/link');
	}

	function update_link(){
		$kode=strip_tags($this->input->post('kode'));
		$judul=strip_tags($this->input->post('xjudul'));
		$deskripsi=$this->input->post('xdeskripsi');
		$this->m_link->update_link($kode,$judul,$deskripsi);
		echo $this->session->set_flashdata('msg','info');
		redirect('peserta/link');
	}
	function hapus_link(){
		$kode=strip_tags($this->input->post('kode'));
		$this->m_link->hapus_link($kode);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('peserta/link');
	}
	
	
	

}