<?php
class Ubahpenerima2015 extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('masukpanitia') != TRUE) {
            $url = base_url('adminpanitia');
            redirect($url);
        };
        $this->load->model('m_ubahpenerima2015');
        // $this->load->library('upload');
    }


    function index()
    {
        $x['data'] = $this->m_ubahpenerima2015->get_cabor();
        $x['data2'] = $this->m_ubahpenerima2015->get_penerima();

        $this->load->view('panitia/v_ubahpenerima2015', $x);
    }
    function ubah_penerima()
    {
        $id_penerima = strip_tags($this->input->post('id_penerima'));
        $id_cabor = strip_tags($this->input->post('id_cabor'));
        $nosk = strip_tags($this->input->post('nosk'));
        $tahunsk = strip_tags($this->input->post('tahunsk'));
        $nm_penerima = strip_tags($this->input->post('nm_penerima'));
        $kat_penghargaan = strip_tags($this->input->post('kat_penghargaan'));
        $jns_penghargaan = strip_tags($this->input->post('jns_penghargaan'));

        //	$id_asdep=strip_tags($this->input->post('id_asdep'));
        //$keterangan=$this->input->post('xketerangan');
        $tgl_rekam = date("Y-m-d H:i:s");
        $this->m_ubahpenerima2015->ubah_penerima($id_penerima, $id_cabor, $nm_penerima, $kat_penghargaan, $nosk, $tahunsk, $jns_penghargaan, $tgl_rekam);
        echo $this->session->set_flashdata('msg', 'info');
        //$x['id_peserta'] = $id_peserta;
        //$id_peserta=strip_tags($this->input->post('id_peserta'));
        redirect('panitia/penerima2015');
    }

    function update_statusssss()
    {

        $config['upload_path'] = './assets/images/'; //path folder
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['encrypt_name'] = TRUE; //nama yang terupload nantinya

        $this->upload->initialize($config);

        if ($this->upload->do_upload('filefoto')) {
            $gbr = $this->upload->data();
            //Compress Image
            $config['image_library'] = 'gd2';
            $config['source_image'] = './assets/images/' . $gbr['file_name'];
            $config['create_thumb'] = FALSE;
            $config['maintain_ratio'] = FALSE;
            $config['quality'] = '100%';
            //  $config['width']= 100%;
            //$config['height']= 100%;
            $config['new_image'] = './assets/images/' . $gbr['file_name'];
            $this->load->library('image_lib', $config);
            $this->image_lib->resize();

            $gambar = $gbr['file_name'];
            // $id_view=$this->input->post('id_view');
            //$jumlah_view=$this->input->post('jumlah_view');
            $id_view = strip_tags($this->input->post('id_view'));
            $jumlah_view = strip_tags($this->input->post('jumlah_view'));

            // $images=$this->input->post('gambar');
            //$path='./assets/images/'.$images;
            //unlink($path);

            $tanggal_update = date("Y-m-d H:i:s");

            $this->m_panitiastatus->update_status($id_view, $jumlah_view, $tanggal_update, $gambar);
            echo $this->session->set_flashdata('msg', 'info');
            redirect('panitia/status?id_view=' . $id_view);
        } else {
            $id_view = strip_tags($this->input->post('id_view'));
            echo $this->session->set_flashdata('msg', 'warning');
            redirect('panitia/status?id_view=' . $id_view);
        }
    }

    function hapus_media()
    {
        //	$kode=$this->input->post('kode');
        //	$album=$this->input->post('album');
        //	$gambar=$this->input->post('gambar');
        //	$path='./assets/images/'.$gambar;
        //	unlink($path);
        $id_view = $this->input->get('id_view');
        $this->m_panitiastatus->hapus_media($id_view);
        echo $this->session->set_flashdata('msg', 'success-hapus');
        redirect('panitia/pesertakeseluruhan');
    }
}
