<?php 
   class Resetpwd extends CI_Controller { 

      function __construct() { 
         parent::__construct(); 
          $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');
        $this->load->helper('string');
        $this->load->model('m_reset');
          //load helper form
         //$this->load->helper('form'); 
      } 

      public function index() { 

         $this->load->helper('form'); 
         $this->load->view('peserta/v_reset'); 

      } 

      public function ubahpass() 
    {
    $email=$this->input->get('email');
    $token=$this->input->get('token');
    $cektoken=$this->m_reset->cektoken($token);
    if($cektoken->num_rows()>0)
                {
                  
                  $this->session->set_userdata('reset_email',$email);
                  $this->load->view('peserta/v_ubahpass'); 
                }
                else
                {
    echo $this->session->set_flashdata('msg','<div class="alert alert-danger" role="alert"><button type="button" class="close" data-dismiss="alert"><span class="fa fa-close"></span></button> Token Salah </div>');
         redirect('resetpwd');  
    }      
    }

    public function passbaru()
    {
        if(!$this->session->userdata('reset_email'))
        {
            redirect('adminpeserta');
        }
           $this->session->set_flashdata("notif","password berhasil di ubah."); 
           
            $passwords=$this->input->post('password');
            $email=$this->session->userdata('reset_email');
            $sandi = password_hash($passwords, PASSWORD_DEFAULT); 
              	$this->m_reset->ubahpass($email,$sandi);
              //	$this->m_reset->ubahpass($email,$sandi);
                
                  $this->session->unset_userdata('reset_email');
               // $this->load->view('https://sapasko.id/resetpwd/ubahpass');
                echo $this->session->set_flashdata('msg','<div class="alert alert-danger" role="alert"><button type="button" class="close" data-dismiss="alert"><span class="fa fa-close"></span></button>  Password Berhasil di Ubah  </div>');
                  redirect('adminpeserta');
                         
        
        
    }


      public function send_mail() 
      { 
         
    
    //$this->form_validation->set_rules('email','Email','required|valid_email');
    
  //   if($this->form_validation->run() != false){
         $email=strip_tags(str_replace("'", "", $this->input->post('email')));
      $cemail=$this->m_reset->cekemail($email);
          $ibu=strip_tags(str_replace("'", "", $this->input->post('ibu')));
      $cekibu=$this->m_reset->cekibu($ibu);
        //echo json_encode($cadmin);
        if($cemail->num_rows() > 0)
            {
                if($cekibu->num_rows()>0)
                {
                    
              
                
         $from_email = "skosapa@gmail.com"; 
         $to_email = $this->input->post('email'); 

         $config = Array(
                'protocol' => 'smtp',
                'smtp_host' => 'ssl://smtp.googlemail.com',
                'smtp_port' => 465,
                'smtp_user' => $from_email,
                'smtp_pass' => 'TMsoftware41#',
                'mailtype'  => 'html', 
                'charset'   => 'iso-8859-1'
        );
         $random = random_string('alnum', 40); 
        $htmlContent = "Silakan Klik Link ini untuk merubah password SAPA-SKO ";
        $htmlContent .= "https://sapasko.id/resetpwd/ubahpass?";
        $htmlContent .= "email=";
        $htmlContent .= $email;
        $htmlContent .= "&token=";
        $htmlContent .= $random;
            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");   

         $this->email->from($from_email, 'SAPA-SKO'); 
         $this->email->to($to_email);
         $this->email->subject('Ubah Password SAPA-SKO'); 
         $this->email->message($htmlContent); 

         //Send mail 
         if($this->email->send()){
                $this->session->set_flashdata("notif","berhasil di kirim ke Email."); 
                
                 $this->m_reset->inputtoken(array(
                  //  'nama_barang'       => $barang,
                    //'kode_barang'       => $kodebarang,
                    //'stok'      =>$stok
                
                //'id_peserta'=>$id_peserta,
                'email'=>$email,
                'token'=>$random
                ));
                  $this->load->view('peserta/v_reset'); 
                  
                  
                          }else {
                $this->session->set_flashdata("notif","Email gagal dikirim."); 
                 $this->load->view('peserta/v_reset'); 
         } 
                }
                else
                {
                    echo $this->session->set_flashdata('msg','<div class="alert alert-danger" role="alert"><button type="button" class="close" data-dismiss="alert"><span class="fa fa-close"></span></button>  Nama Ibu  Tidak Terdaftar di Database </div>');
         redirect('resetpwd');
         
                }
                
              }
        else
        {
     
                echo $this->session->set_flashdata('msg','<div class="alert alert-danger" role="alert"><button type="button" class="close" data-dismiss="alert"><span class="fa fa-close"></span></button>  Email  Tidak Terdaftar di Database </div>');
         redirect('resetpwd');
         
         
     }
      
   //  else{
         
     //     $this->load->view('peserta/v_reset'); 
         
     //}
      }
} 