<?php
class Peserta extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('adminpeserta');
            redirect($url);
        };
		$this->load->model('m_peserta');
		$this->load->library('upload');
	}


	function index(){
//	$kode=$this->session->userdata('idadmin');
//		$x['user']=$this->m_peserta->get_peserta_login($kode);
		$x['data']=$this->m_peserta->get_all_peserta();
		$this->load->view('peserta/v_peserta',$x);
	}

	function update_peserta()
	{
	            $config['upload_path'] = './assets/images/'; //path folder
	            $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
	            $config['encrypt_name'] = TRUE; //nama yang terupload nantinya

	            $this->upload->initialize($config);
	            if(!empty($_FILES['filefoto']['name']))
	            {
	                if ($this->upload->do_upload('filefoto'))
	                {
	                        $gbr = $this->upload->data();
	                        //Compress Image
	                        $config['image_library']='gd2';
	                        $config['source_image']='./assets/images/'.$gbr['file_name'];
	                        $config['create_thumb']= FALSE;
	                        $config['maintain_ratio']= FALSE;
	                        $config['quality']= '60%';
	                        $config['width']= 250;
	                        $config['height']= 400;
	                        $config['new_image']= './assets/images/'.$gbr['file_name'];
	                        $this->load->library('image_lib', $config);
	                        $this->image_lib->resize();
	                $gambar=$gbr['file_name'];
	                
	                $id_peserta=$this->input->post('id_peserta');
                    $nisn=$this->input->post('xnisn');
                    $nama_peserta=$this->input->post('xnama_peserta');
                    $email_peserta=$this->input->post('xemail_peserta');
                    $jns_kelamin=$this->input->post('xjenkel');
                    $tmpt_lahir=$this->input->post('xtmpt_lahir');
                    $tgl_lahir=$this->input->post('xtgl_lahir');
                    $tinggi_badan=$this->input->post('xtinggi_badan');
                    $berat_badan=$this->input->post('xberat_badan');
                    $gol_darah=$this->input->post('xgol_darah');
                    $agama=$this->input->post('xagama');
                    $alamat_rumah=$this->input->post('xalamat_rumah');
                    $hp=$this->input->post('xhp');
                    $nama_bapak=$this->input->post('xnama_bapak');
                    $tinggi_bapak=$this->input->post('xtinggi_bapak');
                    $nama_ibu=$this->input->post('xnama_ibu');
                    $tinggi_ibu=$this->input->post('xtinggi_ibu');
                    $jml_saudara=$this->input->post('xjml_saudara');
                    $hobby=$this->input->post('xhobby');
	                $password=$this->input->post('xpassword');
                    $konfirm_password=$this->input->post('xpassword2');
                  
                    /*
                        $id_peserta,$nisn,$nama_peserta,$email_peserta,$jns_kelamin,$tmpt_lahir, $tgl_lahir,$tinggi_badan, $berat_badan,$gol_darah, $agama, $alamat_rumah, $hp, $nama_bapak, $tinggi_bapak, $nama_ibu, $tinggi_ibu, $jml_saudara, $hobby, $password
                    */
                    if (empty($password) && empty($konfirm_password)) 
                    
                        {
                            	$this->m_peserta->update_peserta_tanpa_pass($id_peserta,
                            	        $nisn,
                            	        $nama_peserta,
                            	        $email_peserta, 
                            	        $jns_kelamin, 
                            	        $tmpt_lahir, 
                            	        $tgl_lahir, 
                            	        $tinggi_badan, 
                            	        $berat_badan,
                            	        $gol_darah, 
                            	        $agama, 
                            	        $alamat_rumah, 
                            	        $hp, 
                            	        $nama_bapak, 
                            	        $tinggi_bapak, 
                            	        $nama_ibu, 
                            	        $tinggi_ibu, 
                            	        $jml_saudara, 
                            	        $hobby, 
                            	        $gambar);
	                    		echo $this->session->set_flashdata('msg','info');
	               				redirect('peserta/peserta');
     						}
     						elseif ($password <> $konfirm_password) 
     						{
     							echo $this->session->set_flashdata('msg','error');
	               				redirect('peserta/peserta');
     						}else{
	               				$this->m_peserta->update_peserta(
	               				$id_peserta,
	               				$nisn,
	               				$nama_peserta,
	               				$email_peserta,
	               				$jns_kelamin,
	               				$tmpt_lahir, 
	               				$tgl_lahir,
	               				$tinggi_badan, 
	               				$berat_badan,
	               				$gol_darah, 
	               				$agama, 
	               				$alamat_rumah, 
	               				$hp, 
	               				$nama_bapak, 
	               				$tinggi_bapak, 
	               				$nama_ibu, 
	               				$tinggi_ibu, 
	               				$jml_saudara, 
	               				$hobby, 
	               				$password, 
	               				$gambar);
	                    		echo $this->session->set_flashdata('msg','info');
	               				redirect('peserta/peserta');
	               			}
	                    
	                }else{
	                    echo $this->session->set_flashdata('msg','warning');
	                    redirect('peserta/peserta');
	                }
	                
	            }else{
	            	
	            	$id_peserta=$this->input->post('id_peserta');
                    $nisn=$this->input->post('xnisn');
                    $nama_peserta=$this->input->post('xnama_peserta');
                    $email_peserta=$this->input->post('xemail_peserta');
                    $jns_kelamin=$this->input->post('xjenkel');
                    $tmpt_lahir=$this->input->post('xtmpt_lahir');
                    $tgl_lahir=$this->input->post('xtgl_lahir');
                    $tinggi_badan=$this->input->post('xtinggi_badan');
                    $berat_badan=$this->input->post('xberat_badan');
                    $gol_darah=$this->input->post('xgol_darah');
                    $agama=$this->input->post('xagama');
                    $alamat_rumah=$this->input->post('xalamat_rumah');
                    $hp=$this->input->post('xhp');
                    $nama_bapak=$this->input->post('xnama_bapak');
                    $tinggi_bapak=$this->input->post('xtinggi_bapak');
                    $nama_ibu=$this->input->post('xnama_ibu');
                    $tinggi_ibu=$this->input->post('xtinggi_ibu');
                    $jml_saudara=$this->input->post('xjml_saudara');
                    $hobby=$this->input->post('xhobby');
	                $password=$this->input->post('xpassword');
                    $konfirm_password=$this->input->post('xpassword2');
                    
	            	if (empty($password) && empty($konfirm_password)) {
                       	$this->m_peserta->update_peserta_tanpa_pass_dan_gambar($id_peserta,$nisn,$nama_peserta,$email_peserta,$jns_kelamin,$tmpt_lahir, $tgl_lahir,$tinggi_badan, $berat_badan,$gol_darah, $agama, $alamat_rumah, $hp, $nama_bapak, $tinggi_bapak, $nama_ibu, $tinggi_ibu, $jml_saudara, $hobby);
	                    echo $this->session->set_flashdata('msg','info');
	               		redirect('peserta/peserta');
     				}elseif ($password <> $konfirm_password) {
     					echo $this->session->set_flashdata('msg','error');
	               		redirect('peserta/peserta');
     				}else{
	               		$this->m_peserta->update_peserta_tanpa_gambar($id_peserta,
	               		$nisn,
	               		$nama_peserta,
	               		$email_peserta,
	               		$jns_kelamin,
	               		$tmpt_lahir, 
	               		$tgl_lahir,
	               		$tinggi_badan, 
	               		$berat_badan,
	               		$gol_darah, 
	               		$agama, 
	               		$alamat_rumah, 
	               		$hp, 
	               		$nama_bapak, 
	               		$tinggi_bapak, 
	               		$nama_ibu, 
	               		$tinggi_ibu, 
	               		$jml_saudara, 
	               		$hobby,
	               		$password);
	                    echo $this->session->set_flashdata('msg','warning');
	               		redirect('peserta/peserta');
	               	
	         }   
	                
	   } 

	}

	function hapus_pengguna(){
		$kode=$this->input->post('kode');
		$data=$this->m_peserta->get_pengguna_login($kode);
		$q=$data->row_array();
		$p=$q['pengguna_photo'];
		$path=base_url().'assets/images/'.$p;
		delete_files($path);
		$this->m_peserta->hapus_pengguna($kode);
	    echo $this->session->set_flashdata('msg','success-hapus');
	    redirect('admin/pengguna');
	}

	function reset_password(){
   
        $id=$this->uri->segment(4);
        $get=$this->m_peserta->getusername($id);
        if($get->num_rows()>0){
            $a=$get->row_array();
            $b=$a['pengguna_username'];
        }
        $pass=rand(123456,999999);
        $this->m_peserta->resetpass($id,$pass);
        echo $this->session->set_flashdata('msg','show-modal');
        echo $this->session->set_flashdata('uname',$b);
        echo $this->session->set_flashdata('upass',$pass);
	    redirect('admin/pengguna');
   
    }


}