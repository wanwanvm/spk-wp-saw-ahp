<?php
class prestasi extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('adminpeserta');
            redirect($url);
        };
		$this->load->model('m_prestasi');
		$this->load->library('upload');
	}


	function index(){
		$x['data']=$this->m_prestasi->get_all_prestasi();
		$this->load->view('peserta/v_prestasi',$x);
	}

	function simpan_prestasi(){
		$nama_prestasi=strip_tags($this->input->post('xnama_prestasi'));
		$juara_prestasi=$this->input->post('xjuara_prestasi');
		$tempat_prestasi=$this->input->post('xtempat_prestasi');
		$tahun=$this->input->post('xtahun');
		$this->m_prestasi->simpan_prestasi($nama_prestasi,$juara_prestasi,$tempat_prestasi,$tahun);
		echo $this->session->set_flashdata('msg','success');
		redirect('peserta/prestasi');
	}

	function update_prestasi(){
	    $id_prestasi=$this->input->post('xid_prestasi');
		$nama_prestasi=$this->input->post('xnama_prestasi');
		$juara_prestasi=$this->input->post('xjuara_prestasi');
		$tempat_prestasi=$this->input->post('xtempat_prestasi');
		$tahun=$this->input->post('xtahun');
		$this->m_prestasi->update_prestasi($id_prestasi,$nama_prestasi,$juara_prestasi,$tempat_prestasi,$tahun);
		echo $this->session->set_flashdata('msg','info');
		redirect('peserta/prestasi');
	}
	function hapus_prestasi(){
		$id_prestasi=$this->input->post('xid_prestasi');
		$this->m_prestasi->hapus_prestasi($id_prestasi);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('peserta/prestasi');
	}

}