<?php
class Crop extends Controller {
 
    function index() {
        if(isset($_FILES['file_data'])){
            //get file name from temp direcotory
            $file   = read_file($_FILES['file_data']['tmp_name']);
            $name   = basename($_FILES['file_data']['name']);
            $rnd_name = get_rand_name();    //set random name to avoid the same file name
            $file_ext = find_exts($name);   //get file extension
            $file_name = $rnd_name . '.' . $file_ext; //concatenate file name to its file extension
            $folder = 'files';
            write_file('files/'.$file_name, $file); //write the file to spesific direcotory
            $cropped_name = $this->default_thumb($folder, $rnd_name, $file_ext, 500, 500);   //generate thumbnail to expected width and height
 
            redirect('test/gallery/crop/' . $cropped_name);
        } else {
            $data['main_content'] = 'peserta/crop';
            $this->load->view('template', $data);
        }
    }
}

