<?php
class Link extends CI_Controller{
	function __construct(){
		parent::__construct();
		if($this->session->userdata('masuk') !=TRUE){
            $url=base_url('adminpeserta');
            redirect($url);
        };
		$this->load->model('m_link');
		$this->load->library('upload');
	}


	function index(){
		$x['data']=$this->m_link->get_all_link();
		$this->load->view('peserta/v_link',$x);
	}

	function simpan_link(){
		$judul=strip_tags($this->input->post('xjudul'));
		$deskripsi=$this->input->post('xdeskripsi');
		$this->m_link->simpan_link($judul,$deskripsi);
		echo $this->session->set_flashdata('msg','success');
		redirect('peserta/link');
	}

	function update_link(){
		$kode=strip_tags($this->input->post('kode'));
		$judul=strip_tags($this->input->post('xjudul'));
		$deskripsi=$this->input->post('xdeskripsi');
		$this->m_link->update_link($kode,$judul,$deskripsi);
		echo $this->session->set_flashdata('msg','info');
		redirect('peserta/link');
	}
	function hapus_link(){
		$kode=strip_tags($this->input->post('kode'));
		$this->m_link->hapus_link($kode);
		echo $this->session->set_flashdata('msg','success-hapus');
		redirect('peserta/link');
	}

}