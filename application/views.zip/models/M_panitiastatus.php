<?php
class M_panitiastatus extends CI_Model{

	function get_all_link(){
	    $id_peserta=$this->session->userdata('id_peserta');
		$hsl=$this->db->query("SELECT tb_link.*  FROM tb_link WHERE  id_peserta  ='$id_peserta'");
		return $hsl;
	}
	function get_asdep(){
		$hasil=$this->db->query("SELECT tb_asdep.* FROM tb_asdep  ");
		return $hasil;
	}
	function get_panitia_status(){
	  //  $id_peserta=$this->session->userdata('id_peserta');
	    $id_proposal=$this->input->get('id_proposal');
		$hsl=$this->db->query("SELECT tb_proposal.*,tb_cabor.*,tb_jns.* FROM tb_proposal,tb_cabor,tb_jns WHERE tb_cabor.id_cabor = tb_proposal.id_cabor and tb_jns.id_jns=tb_proposal.id_jns  and   tb_proposal.id_proposal='$id_proposal'");
		return $hsl;
	}
		function update_status($id_proposal,$tgl_verifikasi,$ket_verifikasi){
	//	$sandi = password_hash($password, PASSWORD_DEFAULT); 
	 		$id_panitia=$this->session->userdata('id_panitia');
		$hsl=$this->db->query("INSERT INTO tb_verifikasi(id_proposal,tgl_verifikasi,ket_verifikasi,id_panitia) VALUES ('$id_proposal','$tgl_verifikasi','$ket_verifikasi','$id_panitia')");
		
	
		$hsl2=$this->db->query("UPDATE tb_verifikasi SET sts='VERIFIKASI' where id_proposal='$id_proposal'");
		return $hsl2;
			return $hsl;
	}
	
	function tambah_media($judul_view,$jns_view,$tanggal_update,$gambar,$link_view,$jumlah_view,$status){
	//	$sandi = password_hash($password, PASSWORD_DEFAULT); 
	 		$id_panitia=$this->session->userdata('id_panitia');
	 		
	$hsl=$this->db->query("INSERT INTO tb_view(judul_view,jns_view,tanggal_update,scr_view,link_view,jumlah_view,id_panitia,status) VALUES ('$judul_view','$jns_view','$tanggal_update','$gambar','$link_view','$jumlah_view','$id_panitia','$status')");
		return $hsl;
	
	}
	
	function ceklink($link_view){
        $hasil=$this->db->query("SELECT * FROM tb_view WHERE link_view='$link_view'");
        return $hasil; //return $result->result();
    }
 
	
		function hapus_media($id_view){
        	$hsl=$this->db->query("DELETE FROM tb_view WHERE id_view='$id_view'");
		return $hsl;
        
    }

}
