<?php 
class M_pesertakeseluruhan extends CI_Model{

	function get_peserta_login($kode){
		$hsl=$this->db->query("SELECT * FROM tb_peserta where id_peserta='$kode'");
		return $hsl;
	}
	function get_all_pengguna(){
		$hsl=$this->db->query("SELECT tbl_pengguna.*,IF(pengguna_jenkel='L','Laki-Laki','Perempuan') AS jenkel FROM tbl_pengguna");
		return $hsl;	
	}

    	function get_all_pesertakeseluruhan(){
    	     //$id_peserta=$this->session->userdata('id_peserta');
    	    $hariini= date('Y-m-d');
		$hsl=$this->db->query("SELECT tb_panitia.*,tb_view.* FROM tb_panitia,tb_view where tb_panitia.id_panitia=tb_view.id_panitia ");
		return $hsl;	
	}


function cek_peserta(){
    	     $id_peserta=$this->session->userdata('id_peserta');
		$hsl=$this->db->query("select COUNT(cek) as cek_peserta FROM tb_peserta where cek='BELUM DI CEK' and tb_peserta.id_peserta= '$id_peserta'");
		return $hsl;	
	}
	
	function valid_peserta(){
    	     $id_peserta=$this->session->userdata('id_peserta');
		$hsl=$this->db->query("select COUNT(cek) as valid_peserta FROM tb_peserta where cek='TIDAK VALID' and tb_peserta.id_peserta= '$id_peserta'");
		return $hsl;	
	}
	
        function cek_galeri(){
    	     $id_peserta=$this->session->userdata('id_peserta');
	    	$hsl=$this->db->query("select COUNT(cek) as cek_galeri FROM tbl_galeri where cek='BELUM DI CEK'   AND id_peserta='$id_peserta'");
		return $hsl;	
	}
	  function valid_galeri(){
    	     $id_peserta=$this->session->userdata('id_peserta');
	    	$hsl=$this->db->query("select COUNT(cek) as valid_galeri FROM tbl_galeri where CEK ='TIDAK VALID'  AND id_peserta='$id_peserta'");
		return $hsl;	
	}
	
	
        function cek_link(){
    	     $id_peserta=$this->session->userdata('id_peserta');
	    	$hsl=$this->db->query("select COUNT(cek) as cek_link FROM tb_link where cek='BELUM DI CEK' AND id_peserta='$id_peserta'");
		return $hsl;	
	}
	function valid_link(){
    	     $id_peserta=$this->session->userdata('id_peserta');
	    	$hsl=$this->db->query("select COUNT(cek) as valid_link FROM tb_link where CEK ='TIDAK VALID'  AND id_peserta='$id_peserta'");
		return $hsl;	
	}
	
	 function cek_prestasi(){
    	     $id_peserta=$this->session->userdata('id_peserta');
	    	$hsl=$this->db->query("select COUNT(cek) as cek_prestasi FROM tb_prestasi where cek='BELUM DI CEK'  AND id_peserta='$id_peserta'");
		return $hsl;	
	}
	function valid_prestasi(){
    	     $id_peserta=$this->session->userdata('id_peserta');
	    	$hsl=$this->db->query("select COUNT(cek) as valid_prestasi FROM tb_prestasi where CEK ='TIDAK VALID'  AND id_peserta='$id_peserta'");
		return $hsl;	
	}
	


}