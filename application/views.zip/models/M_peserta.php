<?php
class M_peserta extends CI_Model{

	function get_peserta_login($kode){
		$hsl=$this->db->query("SELECT * FROM tb_peserta where id_peserta='$kode'");
		return $hsl;
	}
	function get_all_pengguna(){
		$hsl=$this->db->query("SELECT tbl_pengguna.*,IF(pengguna_jenkel='L','Laki-Laki','Perempuan') AS jenkel FROM tbl_pengguna");
		return $hsl;	
	}

    	function get_all_peserta(){
    	     $id_peserta=$this->session->userdata('id_peserta');
		$hsl=$this->db->query("SELECT tb_psb.*,tb_cabor.*,tb_peserta.*,tb_posisi.* FROM tb_posisi,tb_psb,tb_cabor,tb_peserta where tb_posisi.id_cabor=tb_cabor.id_cabor and tb_posisi.id_posisi = tb_psb.id_posisi and tb_psb.id_psb=tb_peserta.id_psb and tb_peserta.id_peserta= '$id_peserta'");
		return $hsl;	
	}
	function get_panitia_all_peserta(){
    	     //$id_peserta=$this->session->userdata('id_peserta');
		$id_peserta=$this->input->get('id_peserta');
		$hsl=$this->db->query("SELECT tb_psb.*,tb_cabor.*,tb_peserta.*,tb_posisi.* FROM tb_posisi,tb_psb,tb_cabor,tb_peserta where tb_posisi.id_cabor=tb_cabor.id_cabor and tb_posisi.id_posisi = tb_psb.id_posisi and tb_psb.id_psb=tb_peserta.id_psb and tb_peserta.id_peserta= '$id_peserta'");
		return $hsl;	
	}

	
	
	//UPDATE Peserta
	function update_peserta_tanpa_pass(
	$id_peserta,
	$nisn,
	$nama_peserta,
	$email_peserta,
	$jns_kelamin,
	$tmpt_lahir,
	$tgl_lahir,
	$tinggi_badan,
	$berat_badan,
	$gol_darah,
	$agama, 
	$alamat_rumah, 
	$hp, 
	$nama_bapak, 
	$tinggi_bapak, 
	$nama_ibu, 
	$tinggi_ibu, 
	$jml_saudara, 
	$hobby, 
	$gambar){
		
		$hsl=$this->db->query("UPDATE tb_peserta set 
		nisn='$nisn',
		nama_peserta='$nama_peserta',
		email_peserta='$email_peserta',
		jns_kelamin='$jns_kelamin',
		tmpt_lahir='$tmpt_lahir',
		tgl_lahir='$tgl_lahir',
		tinggi_badan='$tinggi_badan',
		berat_badan='$berat_badan',
		gol_darah='$gol_darah',
		agama='$agama',
		alamat_rumah='$alamat_rumah',
		hp='$hp',
		nama_bapak='$nama_bapak',
		tinggi_bapak='$tinggi_bapak',
		nama_ibu='$nama_ibu',
		tinggi_ibu='$tinggi_ibu',
		jml_saudara='$jml_saudara',
		hobby='$hobby',
		foto_peserta='$gambar'
		where 
		id_peserta='$id_peserta'");
		return $hsl;
	}
	
	function update_peserta($id_peserta,
	$nisn,
	$nama_peserta,
	$email_peserta,
	$jns_kelamin,
	$tmpt_lahir, 
	$tgl_lahir,
	$tinggi_badan, 
	$berat_badan,
	$gol_darah, 
	$agama, 
	$alamat_rumah, 
	$hp, 
	$nama_bapak, 
	$tinggi_bapak, 
	$nama_ibu, 
	$tinggi_ibu, 
	$jml_saudara, 
	$hobby, 
	$password, 
	$gambar){
		$sandi = password_hash($password, PASSWORD_DEFAULT); 
		$hsl=$this->db->query("UPDATE tb_peserta set nisn='$nisn',nama_peserta='$nama_peserta',email_peserta='$email_peserta',jns_kelamin='$jns_kelamin',tmpt_lahir='$tmpt_lahir',tgl_lahir='$tgl_lahir',tinggi_badan='$tinggi_badan',berat_badan='$berat_badan',gol_darah='$gol_darah',agama='$agama',alamat_rumah='$alamat_rumah',hp='$hp',nama_bapak='$nama_bapak',tinggi_bapak='$tinggi_bapak',nama_ibu='$nama_ibu',tinggi_ibu='$tinggi_ibu',jml_saudara='$jml_saudara',hobby='$gambar',foto_peserta='$gambar',sandi_peserta='$sandi' where id_peserta='$id_peserta'");
		return $hsl;
	}

	function update_peserta_tanpa_pass_dan_gambar($id_peserta,$nisn,$nama_peserta,$email_peserta,$jns_kelamin,$tmpt_lahir, $tgl_lahir,$tinggi_badan, $berat_badan,$gol_darah, $agama, $alamat_rumah, $hp, $nama_bapak, $tinggi_bapak, $nama_ibu, $tinggi_ibu, $jml_saudara, $hobby){
	//	$sandi = password_hash($password, PASSWORD_DEFAULT); 
		$hsl=$this->db->query("UPDATE tb_peserta set nisn='$nisn',nama_peserta='$nama_peserta',email_peserta='$email_peserta',jns_kelamin='$jns_kelamin',tmpt_lahir='$tmpt_lahir',tgl_lahir='$tgl_lahir',tinggi_badan='$tinggi_badan',berat_badan='$berat_badan',gol_darah='$gol_darah',agama='$agama',alamat_rumah='$alamat_rumah',hp='$hp',nama_bapak='$nama_bapak',tinggi_bapak='$tinggi_bapak',nama_ibu='$nama_ibu',tinggi_ibu='$tinggi_ibu',jml_saudara='$jml_saudara',hobby='$hobby' where id_peserta='$id_peserta'");
		return $hsl;
	}
	
	function update_peserta_tanpa_gambar($id_peserta, $nisn, $nama_peserta,$email_peserta, $jns_kelamin, $tmpt_lahir, $tgl_lahir, $tinggi_badan, $berat_badan, $gol_darah, $agama, $alamat_rumah, $hp, $nama_bapak, $tinggi_bapak, $nama_ibu, $tinggi_ibu, $jml_saudara, $hobby, $password){
		$sandi = password_hash($password, PASSWORD_DEFAULT); 
		$hsl=$this->db->query("UPDATE tb_peserta set nisn='$nisn',nama_peserta='$nama_peserta',email_peserta='$email_peserta',jns_kelamin='$jns_kelamin',tmpt_lahir='$tmpt_lahir',tgl_lahir='$tgl_lahir',tinggi_badan='$tinggi_badan',berat_badan='$berat_badan',gol_darah='$gol_darah',agama='$agama',alamat_rumah='$alamat_rumah',hp='$hp',nama_bapak='$nama_bapak',tinggi_bapak='$tinggi_bapak',nama_ibu='$nama_ibu',tinggi_ibu='$tinggi_ibu',jml_saudara='$jml_saudara',hobby='$hobby',sandi_peserta='$sandi' where id_peserta='$id_peserta'");
		return $hsl;
	}
	
	
	


}