<?php
class M_panitiacetak extends CI_Model{

	function get_peserta_login($kode){
		$hsl=$this->db->query("SELECT * FROM tb_psb,tb_posisi,tb_cabor,tb_peserta where tb_posisi.id_cabor=tb_cabor.id_cabor and tb_posisi.id_posisi = tb_psb.id_posisi and tb_peserta.id_peserta='$kode'");
		return $hsl;
	}
	function get_all_pengguna(){
		$hsl=$this->db->query("SELECT tbl_pengguna.*,IF(pengguna_jenkel='L','Laki-Laki','Perempuan') AS jenkel FROM tbl_pengguna");
		return $hsl;	
	}

    	function get_peserta(){
    	     $id_peserta=$this->input->get('id_peserta');
		$hsl=$this->db->query("SELECT tb_psb.*,tb_cabor.*,tb_peserta.*,tb_posisi.* FROM tb_posisi,tb_psb,tb_cabor,tb_peserta where tb_posisi.id_cabor=tb_cabor.id_cabor and tb_posisi.id_posisi = tb_psb.id_posisi and tb_peserta.id_peserta= '$id_peserta'");
		return $hsl;	
	}
	
	


}