<?php
class M_registrasi extends CI_Model{

    function get_sukses_registrasi(){
		$hsl=$this->db->query("SELECT * FROM tb_proposal");
		return $hsl;
	}
	
	function get_cabor(){
		$hasil=$this->db->query("SELECT tb_cabor.id_cabor,tb_cabor.nm_cabor FROM tb_cabor,tb_psb,tb_posisi where tb_cabor.id_cabor=tb_posisi.id_cabor and tb_psb.id_posisi=tb_posisi.id_posisi GROUP BY tb_cabor.nm_cabor  ");
		return $hasil;
	}

	function get_posisi($id){
		$hasil=$this->db->query("SELECT tb_psb.id_psb,tb_posisi.nm_posisi FROM tb_posisi,tb_psb WHERE tb_psb.id_posisi=tb_posisi.id_posisi and tb_posisi.id_cabor='$id'");
		return $hasil->result();
	}

	public function inputpeserta($data){
			$this->db->insert('tb_proposal', $data);
		}
    function cekemail($email){
        $hasil=$this->db->query("SELECT * FROM tb_peserta WHERE email_peserta='$email'");
        return $hasil; //return $result->result();
    }
function ceknisn($nisn){
        $hasil=$this->db->query("SELECT * FROM tb_peserta WHERE nisn='$nisn'");
        return $hasil; //return $result->result();
    }
 
// Membuat kode
	public function kode(){
		  $this->db->select('RIGHT(tb_proposal.id_proposal,6) as id_proposal', FALSE);
		  $this->db->order_by('id_proposal','DESC');    
		  $this->db->limit(1);    
		  $query = $this->db->get('tb_proposal');  //cek dulu apakah ada sudah ada kode di tabel.    
		  if($query->num_rows() <> 0){      
			   //cek kode jika telah tersedia    
			   $data = $query->row();      
			   $kode = intval($data->id_proposal) + 1; 
		  }
		  else{      
			   $kode = 1;  //cek jika kode belum terdapat pada table
		  }
			  $tgl=date('dmY'); 
			  $batas = str_pad($kode, 3, "0", STR_PAD_LEFT);    
			  $kodetampil = "SP"."5".$tgl.$batas;  //format kode
			  return $kodetampil;  
		 }

}