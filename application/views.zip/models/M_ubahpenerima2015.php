<?php
class M_ubahpenerima2015 extends CI_Model
{

    function get_cabor()
    {
        // $id_peserta = $this->session->userdata('id_peserta');
        $hsl = $this->db->query("SELECT *  FROM tb_cabor");
        return $hsl;
    }
    function get_asdep()
    {
        $hasil = $this->db->query("SELECT tb_asdep.* FROM tb_asdep  ");
        return $hasil;
    }
    function get_penerima()
    {
        //  $id_peserta=$this->session->userdata('id_peserta');
        $id_penerima = $this->input->get('id_penerima');
        $hsl = $this->db->query("SELECT tb_penerima.*,tb_cabor.* FROM tb_penerima,tb_cabor WHERE tb_cabor.id_cabor = tb_penerima.id_cabor and tb_penerima.id_penerima='$id_penerima'");
        return $hsl;
    }
    function ubah_penerima($id_penerima, $id_cabor, $nm_penerima, $kat_penghargaan, $nosk, $tahunsk, $jns_penghargaan, $tgl_rekam)
    {
        //	$sandi = password_hash($password, PASSWORD_DEFAULT); 
        $id_panitia = $this->session->userdata('id_panitia');



        $hsl2 = $this->db->query("UPDATE tb_penerima SET id_penerima='$id_penerima', id_cabor='$id_cabor', nm_penerima='$nm_penerima',kat_penghargaan='$kat_penghargaan', 
        nosk='$nosk', tahunsk='$tahunsk', jns_penghargaan='$jns_penghargaan', tgl_rekam='$tgl_rekam',id_panitia='$id_panitia'  where id_penerima='$id_penerima'");
        return $hsl2;
    }

    function tambah_media($judul_view, $jns_view, $tanggal_update, $gambar, $link_view, $jumlah_view, $status)
    {
        //	$sandi = password_hash($password, PASSWORD_DEFAULT); 
        $id_panitia = $this->session->userdata('id_panitia');

        $hsl = $this->db->query("INSERT INTO tb_view(judul_view,jns_view,tanggal_update,scr_view,link_view,jumlah_view,id_panitia,status) VALUES ('$judul_view','$jns_view','$tanggal_update','$gambar','$link_view','$jumlah_view','$id_panitia','$status')");
        return $hsl;
    }

    function ceklink($link_view)
    {
        $hasil = $this->db->query("SELECT * FROM tb_view WHERE link_view='$link_view'");
        return $hasil; //return $result->result();
    }


    function hapus_media($id_view)
    {
        $hsl = $this->db->query("DELETE FROM tb_view WHERE id_view='$id_view'");
        return $hsl;
    }
}
