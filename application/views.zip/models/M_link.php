<?php
class M_link extends CI_Model{

	function get_all_link(){
	    $id_peserta=$this->session->userdata('id_peserta');
		$hsl=$this->db->query("SELECT tb_link.*  FROM tb_link WHERE  id_peserta  ='$id_peserta'");
		return $hsl;
	}
	function simpan_link($judul,$deskripsi){
		$id_peserta=$this->session->userdata('id_peserta');
		$hsl=$this->db->query("INSERT INTO tb_link(nama_link,url_link,id_peserta) VALUES ('$judul','$deskripsi','$id_peserta')");
		return $hsl;
	}
	function update_link($kode,$judul,$deskripsi){
		//$author=$this->session->userdata('nama');
		$hsl=$this->db->query("UPDATE tb_link SET nama_link='$judul',url_link='$deskripsi' where id_link='$kode'");
		return $hsl;
	}
	function hapus_link($kode){
		$hsl=$this->db->query("DELETE FROM tb_link WHERE id_link='$kode'");
		return $hsl;
	}

	//Front-end
	function get_pengumuman_home(){
		$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC limit 3");
		return $hsl;
	}

	function pengumuman(){
		$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC");
		return $hsl;
	}
	function pengumuman_perpage($offset,$limit){
		$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,pengumuman_tanggal,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC limit $offset,$limit");
		return $hsl;
	}


}
