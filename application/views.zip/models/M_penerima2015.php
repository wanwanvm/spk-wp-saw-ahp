<?php 
class M_penerima2015 extends CI_Model{

	function get_peserta_login($kode){
		$hsl=$this->db->query("SELECT * FROM tb_peserta where id_peserta='$kode'");
		return $hsl;
	}
		function hapus_penerima($id_penerima){
		$hsl=$this->db->query("DELETE FROM tb_penerima WHERE id_penerima='$id_penerima'");
		return $hsl;
	}
	function get_all_pengguna(){
		$hsl=$this->db->query("SELECT tbl_pengguna.*,IF(pengguna_jenkel='L','Laki-Laki','Perempuan') AS jenkel FROM tbl_pengguna");
		return $hsl;	
	}

    	function get_all_penerima2015(){
    	     //$id_peserta=$this->session->userdata('id_peserta');
    	    $hariini= date('Y-m-d');
		$hsl=$this->db->query("SELECT tb_penerima.id_penerima,
		                            tb_penerima.id_proposal,
		                            tb_penerima.nm_penerima,
		                            tb_cabor.nm_cabor,
		                            tb_panitia.nama_panitia,
		                            tb_panitia.id_panitia,
		                            tb_penerima.nosk,
		                            tb_penerima.tahunsk,
		                            tb_penerima.kat_penghargaan,
		                            tb_penerima.jns_penghargaan,
		                            tb_penerima.tgl_rekam
		                            
		                            FROM tb_penerima JOIN tb_cabor ON tb_cabor.id_cabor = tb_penerima.id_cabor JOIN tb_panitia ON tb_penerima.id_panitia = tb_panitia.id_panitia LEFT JOIN tb_proposal ON tb_proposal.id_proposal = tb_penerima.id_proposal  ");
		return $hsl;	
	}



	


}