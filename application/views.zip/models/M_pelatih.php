<?php 
class M_pelatih extends CI_Model{

	function get_all_pelatih(){
		$hsl=$this->db->query("SELECT tbl_pelatih.*,cabor_nama FROM tbl_pelatih JOIN tbl_cabor ON pelatih_cabor_id=cabor_id");
		return $hsl;
	}

	function simpan_pelatih($nik,$hp,$email,$nama,$jenkel,$tmp_lahir,$tgl_lahir,$cabor,$photo,$alamat){
		$hsl=$this->db->query("INSERT INTO tbl_pelatih (pelatih_nik,pelatih_hp,pelatih_email,pelatih_nama,pelatih_jenkel,pelatih_tmp_lahir,pelatih_tgl_lahir,pelatih_cabor_id,pelatih_photo,pelatih_alamat) VALUES ('$nik','$hp','$email','$nama','$jenkel','$tmp_lahir','$tgl_lahir','$cabor','$photo','$alamat')");
		return $hsl;
	}
	function simpan_pelatih_tanpa_img($nik,$hp,$email,$nama,$jenkel,$tmp_lahir,$tgl_lahir,$cabor,$alamat){
		$hsl=$this->db->query("INSERT INTO tbl_pelatih(pelatih_nik,pelatih_hp,pelatih_email,pelatih_nama,pelatih_jenkel,pelatih_tmp_lahir,pelatih_tgl_lahir,pelatih_cabor_id,pelatih_alamat) VALUES ('$nik','$hp','$email','$nama','$jenkel','$tmp_lahir','$tgl_lahir','$cabor','$alamat')");
		return $hsl;
	}

	function update_pelatih($kode,$nik,$hp,$email,$nama,$jenkel,$tmp_lahir,$tgl_lahir,$cabor,$photo,$alamat){
		$hsl=$this->db->query("UPDATE tbl_pelatih SET pelatih_nik='$nik',pelatih_hp='$hp',pelatih_email='$email',pelatih_alamat='$alamat',pelatih_nama='$nama',pelatih_jenkel='$jenkel',pelatih_tmp_lahir='$tmp_lahir',pelatih_tgl_lahir='$tgl_lahir',pelatih_cabor_id='$cabor',pelatih_photo='$photo' WHERE pelatih_id='$kode'");
		return $hsl;
	}
	function update_pelatih_tanpa_img($kode,$nik,$hp,$email,$nama,$jenkel,$tmp_lahir,$tgl_lahir,$cabor,$alamat){
		$hsl=$this->db->query("UPDATE tbl_pelatih SET pelatih_nik='$nik',pelatih_hp='$hp',pelatih_email='$email',pelatih_alamat='$alamat',pelatih_nama='$nama',pelatih_jenkel='$jenkel',pelatih_tmp_lahir='$tmp_lahir',pelatih_tgl_lahir='$tgl_lahir',pelatih_cabor_id='$cabor' WHERE pelatih_id='$kode'");
		return $hsl;
	}
	function hapus_pelatih($kode){
		$hsl=$this->db->query("DELETE FROM tbl_pelatih WHERE pelatih_id='$kode'");
		return $hsl;
	}

	//front-end
	function pelatih(){
		$hsl=$this->db->query("SELECT tbl_pelatih.*,cabor_nama FROM tbl_pelatih JOIN tbl_cabor ON pelatih_cabor_id=cabor_id ORDER BY pelatih_cabor_id ASC");
		return $hsl;
	}
	function pelatih_perpage($offset,$limit){
		$hsl=$this->db->query("SELECT tbl_pelatih.*,cabor_nama FROM tbl_pelatih JOIN tbl_cabor ON pelatih_cabor_id=cabor_id ORDER BY pelatih_cabor_id ASC limit $offset,$limit ");
		return $hsl;
	}

}