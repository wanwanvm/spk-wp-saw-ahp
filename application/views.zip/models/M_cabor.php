<?php
class M_cabor extends CI_Model{

	function get_all_cabor(){
		$hsl=$this->db->query("SELECT * FROM tbl_cabor");
		return $hsl;
	}

}