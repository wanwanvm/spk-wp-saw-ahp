<?php
class M_reset extends CI_Model{
    
     function cekemail($email){
        $hasil=$this->db->query("SELECT * FROM tb_peserta WHERE email_peserta='$email'");
        return $hasil; //return $result->result();
    }
    function cekibu($ibu){
        $hasil=$this->db->query("SELECT * FROM tb_peserta WHERE nama_ibu='$ibu'");
        return $hasil; //return $result->result();
    }
    public function inputtoken($data){
			$this->db->insert('tb_token', $data);
		}
function cektoken($token){
        $hasil=$this->db->query("SELECT * FROM tb_token WHERE token='$token'");
        return $hasil; //return $result->result();
    }
    
function ubahpass($email,$sandi)
{
	
		
			$this->db->trans_start();
            $this->db->query("delete from tb_token where email='$email'");
            $this->db->query("update tb_peserta set sandi_peserta='$sandi' where email_peserta='$email'");
        $this->db->trans_complete();
        if($this->db->trans_status()==true)
        return true;
        else
        return false;
		
	}

    
}