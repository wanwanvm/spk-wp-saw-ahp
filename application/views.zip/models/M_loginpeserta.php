<?php
class M_loginpeserta extends CI_Model{
    function cekadmin($up,$pp){
     //   $hasil=$this->db->query("SELECT * FROM tb_peserta WHERE nisn='$u' AND 
     //sandi_peserta=md5('$p')");
     $hasil=$this->db->query("SELECT * FROM tb_peserta WHERE email_peserta='$up'");
     
        return $hasil; //return $result->result();
    }

}
