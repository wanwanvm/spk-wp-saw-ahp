<?php
// Penduduk.php
class M_penduduk extends CI_Model {
	//public function __construct()
	//{
	//	$this->load->database();
	//}
 
	public function graph()
	{
		$data = $this->db->query("SELECT tb_cabor.nm_cabor,count(tb_cabor.id_cabor) as jumlah from tb_cabor,tb_proposal WHERE tb_cabor.id_cabor=tb_proposal.id_cabor GROUP BY tb_cabor.nm_cabor");
		return $data->result();
	}
 
}