<?php
class M_grafik extends CI_Model{

	function get_data_stok(){
        $query = $this->db->query("SELECT tb_cabor.nm_cabor,count(tb_cabor.id_cabor) as jumlah from tb_cabor,tb_proposal WHERE tb_cabor.id_cabor=tb_proposal.id_cabor GROUP BY tb_cabor.nm_cabor ");
         
        if($query->num_rows() > 0){
            foreach($query->result() as $data){
                $hasil[] = $data;
            }
            return $hasil;
        }
    }

}