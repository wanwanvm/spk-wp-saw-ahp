<?php 
class M_pesertabelumcek extends CI_Model{

	function get_peserta_login($kode){
		$hsl=$this->db->query("SELECT * FROM tb_peserta where id_peserta='$kode'");
		return $hsl;
	}
	function get_all_pengguna(){
		$hsl=$this->db->query("SELECT tbl_pengguna.*,IF(pengguna_jenkel='L','Laki-Laki','Perempuan') AS jenkel FROM tbl_pengguna");
		return $hsl;	
	}

    	function get_all_pesertabelumcek(){
    	    	
    	     //$id_peserta=$this->session->userdata('id_peserta');
    	    $hariini= date('Y-m-d');
		$hsl=$this->db->query("SELECT tb_verifikasi.*,tb_proposal.*,tb_cabor.*,tb_jns.*,tb_disposisi.* FROM tb_verifikasi,tb_disposisi, tb_proposal,tb_cabor,tb_jns WHERE tb_verifikasi.id_proposal=tb_proposal.id_proposal and tb_verifikasi.sts_verifikasi='BERKAS LENGKAP'  and tb_cabor.id_cabor = tb_proposal.id_cabor and tb_jns.id_jns=tb_proposal.id_jns  and   tb_proposal.sts='VERIFIKASI' and tb_disposisi.id_proposal=tb_proposal.id_proposal and tb_disposisi.id_asdep='1' ");
		return $hsl;	
		
	}


function cek_peserta(){
    	     $id_peserta=$this->session->userdata('id_peserta');
		$hsl=$this->db->query("select COUNT(cek) as cek_peserta FROM tb_peserta where cek='BELUM DI CEK' and tb_peserta.id_peserta= '$id_peserta'");
		return $hsl;	
	}
	
	function valid_peserta(){
    	     $id_peserta=$this->session->userdata('id_peserta');
		$hsl=$this->db->query("select COUNT(cek) as valid_peserta FROM tb_peserta where cek='TIDAK VALID' and tb_peserta.id_peserta= '$id_peserta'");
		return $hsl;	
	}
	
        function cek_galeri(){
    	     $id_peserta=$this->session->userdata('id_peserta');
	    	$hsl=$this->db->query("select COUNT(cek) as cek_galeri FROM tbl_galeri where cek='BELUM DI CEK'   AND id_peserta='$id_peserta'");
		return $hsl;	
	}
	  function valid_galeri(){
    	     $id_peserta=$this->session->userdata('id_peserta');
	    	$hsl=$this->db->query("select COUNT(cek) as valid_galeri FROM tbl_galeri where CEK ='TIDAK VALID'  AND id_peserta='$id_peserta'");
		return $hsl;	
	}
	
	
        function cek_link(){
    	     $id_peserta=$this->session->userdata('id_peserta');
	    	$hsl=$this->db->query("select COUNT(cek) as cek_link FROM tb_link where cek='BELUM DI CEK' AND id_peserta='$id_peserta'");
		return $hsl;	
	}
	function valid_link(){
    	     $id_peserta=$this->session->userdata('id_peserta');
	    	$hsl=$this->db->query("select COUNT(cek) as valid_link FROM tb_link where CEK ='TIDAK VALID'  AND id_peserta='$id_peserta'");
		return $hsl;	
	}
	
	 function cek_prestasi(){
    	     $id_peserta=$this->session->userdata('id_peserta');
	    	$hsl=$this->db->query("select COUNT(cek) as cek_prestasi FROM tb_prestasi where cek='BELUM DI CEK'  AND id_peserta='$id_peserta'");
		return $hsl;	
	}
	function valid_prestasi(){
    	     $id_peserta=$this->session->userdata('id_peserta');
	    	$hsl=$this->db->query("select COUNT(cek) as valid_prestasi FROM tb_prestasi where CEK ='TIDAK VALID'  AND id_peserta='$id_peserta'");
		return $hsl;	
	}
	


}