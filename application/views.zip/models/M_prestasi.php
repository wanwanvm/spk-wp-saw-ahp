<?php
class M_prestasi extends CI_Model{

	function get_all_prestasi(){
	    $id_peserta=$this->session->userdata('id_peserta');
		$hsl=$this->db->query("SELECT * FROM tb_prestasi WHERE id_peserta  ='$id_peserta'");
		return $hsl;
	}
	function simpan_prestasi($nama_prestasi,$juara_prestasi,$tempat_prestasi,$tahun){
		$id_peserta=$this->session->userdata('id_peserta');
		$hsl=$this->db->query("INSERT INTO tb_prestasi(nama_prestasi,juara_prestasi,tempat_prestasi,tahun,id_peserta) VALUES ('$nama_prestasi','$juara_prestasi','$tempat_prestasi','$tahun','$id_peserta')");
		return $hsl;
	}
	function update_prestasi($id_prestasi,$nama_prestasi,$juara_prestasi,$tempat_prestasi,$tahun){
		//$author=$this->session->userdata('nama');
		$hsl=$this->db->query("UPDATE tb_prestasi SET nama_prestasi='$nama_prestasi',juara_prestasi='$juara_prestasi',tempat_prestasi='$tempat_prestasi',tahun='$tahun' where id_prestasi='$id_prestasi'");
		return $hsl;
	}
	function hapus_prestasi($id_prestasi){
		$hsl=$this->db->query("DELETE FROM tb_prestasi WHERE id_prestasi='$id_prestasi'");
		return $hsl;
	}

	//Front-end
	function get_pengumuman_home(){
		$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC limit 3");
		return $hsl;
	}

	function pengumuman(){
		$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC");
		return $hsl;
	}
	function pengumuman_perpage($offset,$limit){
		$hsl=$this->db->query("SELECT pengumuman_id,pengumuman_judul,pengumuman_deskripsi,pengumuman_tanggal,DATE_FORMAT(pengumuman_tanggal,'%d/%m/%Y') AS tanggal,pengumuman_author FROM tbl_pengumuman ORDER BY pengumuman_id DESC limit $offset,$limit");
		return $hsl;
	}


}
