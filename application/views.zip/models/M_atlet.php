<?php 
class M_atlet extends CI_Model{

	function get_all_atlet(){
		$hsl=$this->db->query("SELECT tbl_atlet.*,kelas_nama,cabor_nama FROM tbl_atlet JOIN tbl_kelas ON atlet_kelas_id=kelas_id JOIN tbl_cabor ON atlet_cabor_id=cabor_id");
		return $hsl;
	}

	function simpan_atlet($nis,$nama,$jenkel,$kelas,$photo,$cabor){
		$hsl=$this->db->query("INSERT INTO tbl_atlet(atlet_nis,atlet_nama,atlet_jenkel,atlet_kelas_id,atlet_photo,atlet_cabor_id) VALUES ('$nis','$nama','$jenkel','$kelas','$photo','$cabor')");
		return $hsl;
	}
	function simpan_atlet_tanpa_img($nis,$nama,$jenkel,$kelas,$cabor){
		$hsl=$this->db->query("INSERT INTO tbl_atlet(atlet_nis,atlet_nama,atlet_jenkel,atlet_kelas_id,atlet_cabor_id) VALUES ('$nis','$nama','$jenkel','$kelas','$cabor')");
		return $hsl;
	}

	function update_atlet($kode,$nis,$nama,$jenkel,$kelas,$photo,$cabor){
		$hsl=$this->db->query("UPDATE tbl_atlet SET atlet_nis='$nis',atlet_nama='$nama',atlet_jenkel='$jenkel',atlet_kelas_id='$kelas',atlet_photo='$photo',atlet_cabor_id='$cabor' WHERE atlet_id='$kode'");
		return $hsl;
	}
	function update_atlet_tanpa_img($kode,$nis,$nama,$jenkel,$kelas,$cabor){
		$hsl=$this->db->query("UPDATE tbl_atlet SET atlet_nis='$nis',atlet_nama='$nama',atlet_jenkel='$jenkel',atlet_kelas_id='$kelas',atlet_cabor_id='$cabor' WHERE atlet_id='$kode'");
		return $hsl;
	}
	function hapus_atlet($kode){
		$hsl=$this->db->query("DELETE FROM tbl_atlet WHERE atlet_id='$kode'");
		return $hsl;
	}

	function atlet(){
		$hsl=$this->db->query("SELECT tbl_atlet.*,kelas_nama,cabor_nama FROM tbl_atlet JOIN tbl_kelas ON atlet_kelas_id=kelas_id JOIN tbl_cabor ON atlet_cabor_id=cabor_id");
		return $hsl;
	}
	function atlet_perpage($offset,$limit){
		$hsl=$this->db->query("SELECT tbl_atlet.*,kelas_nama,cabor_nama FROM tbl_atlet JOIN tbl_kelas ON atlet_kelas_id=kelas_id JOIN tbl_cabor ON atlet_cabor_id=cabor_id limit $offset,$limit");
		return $hsl;
	}

}